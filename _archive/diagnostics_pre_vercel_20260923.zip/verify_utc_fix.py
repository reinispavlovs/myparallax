﻿from pathlib import Path

src = Path("digest_generator.py").read_text(encoding="utf-8")
lines = src.splitlines()

print("=== First 15 lines (imports) ===")
for i, line in enumerate(lines[:15], 1):
    print(f"{i:3}: {line}")

print("\n=== Occurrences of 'timezone.utc' or 'datetime.UTC' ===")
for i, line in enumerate(lines, 1):
    if "timezone.utc" in line or "datetime.UTC" in line:
        print(f"{i:3}: {line.strip()}")
