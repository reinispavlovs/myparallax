﻿import re
from pathlib import Path
from datetime import datetime, timezone
import shutil
import py_compile

root = Path(".").resolve()
main_path = root / "main.py"
text = main_path.read_text(encoding="utf-8")

history_dir = root / "_history"
history_dir.mkdir(exist_ok=True)
ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup_path = history_dir / f"main.py.bak.{ts}"
shutil.copy2(main_path, backup_path)
print(f"[BACKUP] {backup_path}")

replacements = [
    ("\"NO_SOURCE_FOUND — cilvēkam manuāli jāpievieno atsauce pirms publicēšanas.\",",
     "\"NO_SOURCE_FOUND — a human must manually add a citation before publication.\","),

    ("\"model_note\": \"Standarta akustiskās impedances vienādojums (Z1-Z2)^2/(Z1+Z2)^2. \"",
     "\"model_note\": \"Standard acoustic impedance mismatch equation (Z1-Z2)^2/(Z1+Z2)^2. \""),
    ("\"NAV iekļauts izgudrots pjezoelektriskā lādiņa aprēķins — tas tika \"",
     "\"Does NOT include a fabricated piezoelectric charge calculation — it was \""),
    ("\"identificēts kā nepamatots un noņemts.\",",
     "\"identified as unsubstantiated and removed.\","),

    ("\"model_note\": \"Sinusoidāls modelis TIKAI ilustrācijai — nav ģeoloģisks mērījums.\",",
     "\"model_note\": \"Sinusoidal model for ILLUSTRATION ONLY — not a geological measurement.\","),

    ("\"model_note\": \"Iepriekšējā versijā šeit bija hardkodēts skaitlis (0.84) bez atsauces. \"",
     "\"model_note\": \"A previous version hardcoded a number (0.84) here without a citation. \""),
    ("\"Tas ir noņemts. Cilvēkam PIRMS publicēšanas jāpievieno konkrēts \"",
     "\"It has been removed. A human must add a specific \""),
    ("\"pētījums un tā ziņotais rādītājs.\",",
     "\"study and its reported figure PRIOR to publication.\","),

    ("\"model_note\": \"Strukturālās līdzības apgalvojumi (piem., Vazza & Feletti tipa salīdzinājumi) \"",
     "\"model_note\": \"Structural-similarity claims (e.g., Vazza & Feletti-type comparisons) \""),
    ("\"prasa konkrētu citējamu pētījumu ar metodoloģiju — bez tā nav publicējams \"",
     "\"require a specific, citable study with methodology — without it, no \""),
    ("\"kvantitatīvs apgalvojums.\",",
     "\"quantitative claim is publishable.\","),

    ("f\"Failsafe check: {sim_data['energy_reflection_pct']:.2f}% akustiskās energijas atstarošanās \"",
     "f\"Failsafe check: The {sim_data['energy_reflection_pct']:.2f}% acoustic energy reflection figure \""),
    ("\"aprēķins ir standarta impedances fizika, NE arheoloģisks pierādījums par nodomu. \"",
     "\"is standard impedance physics, NOT archaeological proof of intent. \""),
    ("\"Gaisa akustiskie viļņi vien nevar pārvarēt akmens masu bez papildu savienojuma mehānisma \"",
     "\"Airborne acoustic waves alone cannot overcome stone mass without an additional coupling mechanism \""),
    ("\"(seismiska sprieguma vai slēgtas Helmholtz ģeometrijas).\"",
     "\"(seismic strain or a closed Helmholtz geometry).\""),

    ("\"Cautionary check: Matemātiskais cikliskais modelis ir ILUSTRATĪVS, ne pierādīts korelācijas mehānisms. \"",
     "\"Cautionary check: The mathematical cyclical model is ILLUSTRATIVE, not a proven correlation mechanism. \""),
    ("\"Nogulumu platīna pīķi (~12 800 BP) liecina par ārēju trieciena notikumu, kas ir ATSEVIŠĶS jautājums \"",
     "\"The sediment platinum peak (~12,800 BP) indicates an external impact event, which is a SEPARATE issue \""),
    ("\"no orbitālās mehānikas cikla — šos divus NEDRĪKST sajaukt vienā secinājumā.\"",
     "\"from the orbital mechanics cycle — the two must NOT be conflated into a single conclusion.\""),

    ("\"Methodological check: Subjektīvo ziņojumu patiesuma (veridicality) apstiprināšanai nepieciešams \"",
     "\"Methodological check: Confirming the veridicality of subjective reports requires \""),
    ("\"konkrēts, citējams pētījums ar metodoloģiju. Bez tā NEVIENS skaitlis vai apgalvojums \"",
     "\"a specific, citable study with methodology. Without it, NO figure or claim \""),
    ("\"NAV publicējams kā fakts.\"",
     "\"is publishable as fact.\""),

    ("\"Methodological check: Vizuāla vai topoloģiska 'līdzība' starp diviem tīkliem (neironu un kosmiskā \"",
     "\"Methodological check: A visual or topological 'resemblance' between two networks (neural and cosmic \""),
    ("\"tīkla) NAV cēloniska saikne un NEDRĪKST tikt prezentēta kā zinātnisks 'izomorfisms' bez konkrēta \"",
     "\"web) is NOT a causal link and must NOT be presented as a scientific 'isomorphism' without a specific \""),
    ("\"kvantitatīva salīdzinājuma pētījuma ar norādītu metriku un atsauci.\"",
     "\"quantitative comparison study with a stated metric and citation.\""),
]

errors = []
new_text = text
for old, new in replacements:
    count = new_text.count(old)
    if count != 1:
        errors.append((old, count))
    else:
        new_text = new_text.replace(old, new)

if errors:
    print("\n[ABORT] Some replacements did not match exactly once. No changes written.")
    for old, count in errors:
        print(f"  count={count}: {old[:90]}")
else:
    anchor = "f\"Use ONLY this dataset — do not invent additional numbers: {verified_data}. \""
    if new_text.count(anchor) != 1:
        print(f"[WARN] Prompt anchor count={new_text.count(anchor)}. Skipping prompt safeguard.")
    else:
        injected = (
            anchor + "\n"
            "        \"0. Write your ENTIRE response in English only, regardless of the language of any \"\n"
            "        \"notes, critiques, or source text provided above. Translate any non-English fragments \"\n"
            "        \"into English before including them in your output. \""
        )
        new_text = new_text.replace(anchor, injected, 1)
        print("[OK] English-only directive injected into Agent 3 prompt.")

    main_path.write_text(new_text, encoding="utf-8", newline="")
    print(f"[OK] Patched {main_path} ({len(replacements)} strings translated)")

    try:
        py_compile.compile(str(main_path), doraise=True)
        print("[OK] main.py compiles successfully.")
    except py_compile.PyCompileError as e:
        print(f"[ERROR] Compile failed after patch: {e}")
