﻿import sys
from pathlib import Path
sys.path.insert(0, str(Path(".").resolve()))

import main as m

topic = None
for t in m.TOPICS:
    if t["id"] == "consciousness_independence_nde":
        topic = t
        break

if topic is None:
    print("[FAIL] Topic not found in main.TOPICS")
    raise SystemExit(1)

result = m.fetch_real_arxiv_summary(topic["arxiv_query"])
print("=== fetch_real_arxiv_summary result for NDE topic ===")
if result is None:
    print("No relevant candidate found (below threshold).")
else:
    for k, v in result.items():
        print(f"{k}: {v}")
