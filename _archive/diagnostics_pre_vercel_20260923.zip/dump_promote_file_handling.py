﻿from pathlib import Path
import re

REPO_ROOT = Path(".").resolve()
target = REPO_ROOT / "scripts" / "promote_drafts.py"
text = target.read_text(encoding="utf-8")
lines = text.splitlines()

print(f"Total lines: {len(lines)}")
print()

# Find the core promotion logic - look for shutil, copy, move, rename, unlink near "promote" function
for i, line in enumerate(lines, start=1):
    if any(kw in line for kw in ["shutil", ".copy", ".move", ".rename", ".unlink", "def promote", "content/articles", "content" + chr(92) + "articles"]):
        start = max(0, i-2)
        end = min(len(lines), i+2)
        print(f"--- around line {i} ---")
        for j in range(start, end):
            print(f"{j+1}: {lines[j]}")
        print()
