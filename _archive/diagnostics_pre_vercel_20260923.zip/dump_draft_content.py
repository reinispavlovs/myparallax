﻿import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
DRAFTS_DIR = REPO_ROOT / "drafts"

if len(sys.argv) < 2:
    print("Usage: python dump_draft_content.py <partial-filename-match>")
    print("\nAvailable drafts:")
    for f in sorted(DRAFTS_DIR.glob("*.html")):
        print(f"  {f.name}")
    sys.exit(1)

match = sys.argv[1]
candidates = list(DRAFTS_DIR.glob(f"*{match}*.html"))

if not candidates:
    print(f"No draft found matching '{match}'")
    sys.exit(1)
if len(candidates) > 1:
    print(f"Multiple matches found, please be more specific:")
    for c in candidates:
        print(f"  {c.name}")
    sys.exit(1)

html_path = candidates[0]
with open(html_path, "r", encoding="utf-8") as f:
    content = f.read()

print(f"=== FULL CONTENT: {html_path.name} ===\n")
print(content)
print(f"\n=== END OF FILE ({len(content)} chars) ===")
