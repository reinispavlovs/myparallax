﻿import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
main_path = REPO_ROOT / "main.py"

with open(main_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

print(f"Total lines in main.py: {len(lines)}\n")

# Find Agent 3 related sections: prompt construction, model_note, skeptic_critique assembly
keywords = ["grok-4.6", "model_note", "skeptic_critique", "system_prompt", "SYSTEM_PROMPT",
            "Agent 3", "AGENT_3", "temperature=0.3", "def agent3", "def author"]

hits = []
for i, line in enumerate(lines, start=1):
    for kw in keywords:
        if kw in line:
            hits.append((i, kw, line.rstrip()))

print("=== Keyword hit locations ===")
for i, kw, line in hits:
    print(f"L{i:4} [{kw}]: {line}")

print("\n=== Dumping lines around first system_prompt / Agent3 block ===")
target_line = None
for i, kw, line in hits:
    if kw in ("system_prompt", "SYSTEM_PROMPT", "def agent3", "def author", "Agent 3", "AGENT_3"):
        target_line = i
        break

if target_line:
    start = max(0, target_line - 5)
    end = min(len(lines), target_line + 60)
    for i in range(start, end):
        print(f"{i+1:4}: {lines[i]}", end="")
else:
    print("[WARN] No clear Agent 3 prompt block found via keywords.")
