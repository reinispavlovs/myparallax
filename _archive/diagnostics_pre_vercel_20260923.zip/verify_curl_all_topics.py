﻿import sys
sys.path.insert(0, ".")
from main import fetch_real_arxiv_summary, TOPICS

for topic in TOPICS:
    query = topic["arxiv_query"]
    result = fetch_real_arxiv_summary(query)
    print(f"=== {topic['id']} ===")
    print(f"query: {query}")
    print(f"found: {result['found']}")
    if result["found"]:
        print(f"overlap: {result.get('relevance_overlap_count')}, ratio: {result.get('relevance_overlap_ratio')}")
        print(f"text preview: {result['text'][:120]}")
    else:
        print(f"note: {result.get('note')}")
    print()
