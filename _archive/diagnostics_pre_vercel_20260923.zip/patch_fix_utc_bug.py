﻿from pathlib import Path
import re
import shutil
from datetime import datetime, timezone

target = Path("digest_generator.py")
src = target.read_text(encoding="utf-8")

if "datetime.now(datetime.UTC)" not in src:
    print("[SKIP] Bug pattern not found -- may already be fixed or different form.")
else:
    backup_dir = Path("digests/_history")
    backup_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_path = backup_dir / f"digest_generator.py.bak.{ts}"
    shutil.copy2(target, backup_path)
    print(f"[BACKUP] {backup_path}")

    new_src = src

    # Ensure UTC is importable at module level
    if re.search(r"^from datetime import datetime\s*$", new_src, re.MULTILINE):
        new_src = re.sub(
            r"^from datetime import datetime\s*$",
            "from datetime import datetime, timezone",
            new_src,
            count=1,
            flags=re.MULTILINE,
        )
        print("[PATCH] Import updated to include timezone.")
    elif "timezone" not in new_src.split("\n")[0:20]:
        print("[WARN] Could not confirm import line pattern -- manual check needed.")

    # Replace broken usage with correct one
    count = new_src.count("datetime.now(datetime.UTC)")
    new_src = new_src.replace("datetime.now(datetime.UTC)", "datetime.now(timezone.utc)")
    print(f"[PATCH] Replaced {count} occurrence(s) of datetime.now(datetime.UTC) -> datetime.now(timezone.utc)")

    target.write_text(new_src, encoding="utf-8", newline="")
    print("[DONE] digest_generator.py patched.")
