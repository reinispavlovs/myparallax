﻿import json
from pathlib import Path

REPO_ROOT = Path(".").resolve()
log_path = REPO_ROOT / "digests" / "promote_log.jsonl"
lines = log_path.read_text(encoding="utf-8").strip().splitlines()

print(f"[INFO] Total log entries: {len(lines)}")
print("=" * 70)
for line in lines[-4:]:
    entry = json.loads(line)
    print(f"topic       : {entry.get('topic_id')}")
    print(f"score       : {entry.get('credibility_score_C_i') or entry.get('score')}")
    print(f"promoted_at : {entry.get('promoted_at')}")
    print(f"reviewer    : {entry.get('reviewer')}")
    print("-" * 70)
