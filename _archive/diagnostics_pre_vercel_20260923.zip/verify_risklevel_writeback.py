﻿import json
from pathlib import Path

REPO_ROOT = Path(".").resolve()
DRAFTS_DIR = REPO_ROOT / "drafts"

print("=" * 70)
print("[1] Running digest_generator.py")
print("=" * 70)
import subprocess
result = subprocess.run(
    ["python", "-u", str(REPO_ROOT / "digest_generator.py")],
    capture_output=True, text=True, cwd=str(REPO_ROOT)
)
print(result.stdout[-1500:])
if result.returncode != 0:
    print("[STDERR]")
    print(result.stderr[-1500:])

print()
print("=" * 70)
print("[2] Auditing risk_level in each draft's meta.json")
print("=" * 70)
for meta_path in sorted(DRAFTS_DIR.glob("*.meta.json")):
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    print(f"{meta_path.name}: topic={meta.get('topic_id')}, "
          f"risk_level={meta.get('risk_level')!r}, "
          f"C_i={meta.get('credibility_score_C_i')}, "
          f"promoted={meta.get('promoted')}")
