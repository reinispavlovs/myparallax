﻿import json
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
WEIGHTS_PATH = REPO_ROOT / "content" / "articles" / "topic_weights.json"
PROMOTE_PATH = REPO_ROOT / "scripts" / "promote_drafts.py"

print("=== topic_weights.json (full content) ===")
data = json.loads(WEIGHTS_PATH.read_text(encoding="utf-8"))
print(json.dumps(data, indent=2, ensure_ascii=False))

print("\n=== promote_drafts.py bump_weight() source (lines 220-265) ===")
lines = PROMOTE_PATH.read_text(encoding="utf-8").splitlines()
for i in range(219, min(265, len(lines))):
    print(f"{i+1:4}: {lines[i]}")
