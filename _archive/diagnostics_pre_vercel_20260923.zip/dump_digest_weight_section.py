﻿from pathlib import Path

REPO_ROOT = Path(".").resolve()
DIGEST_GEN = REPO_ROOT / "digest_generator.py"

text = DIGEST_GEN.read_text(encoding="utf-8")
lines = text.splitlines()

print(f"=== digest_generator.py total lines: {len(lines)} ===\n")

targets = ["topic_weights", "current_weight", "weight_history", "topic_weight"]
hit_lines = set()
for i, line in enumerate(lines, start=1):
    low = line.lower()
    if any(t in low for t in targets):
        hit_lines.add(i)

if not hit_lines:
    print("[INFO] No weight-related references found in digest_generator.py.")
else:
    print(f"=== {len(hit_lines)} matching lines (with context) ===\n")
    shown = set()
    for ln in sorted(hit_lines):
        start = max(1, ln - 3)
        end = min(len(lines), ln + 3)
        for n in range(start, end + 1):
            if n not in shown:
                marker = ">>" if n in hit_lines else "  "
                print(f"{marker} {n:4}: {lines[n-1]}")
                shown.add(n)
        print("   ...")
