﻿import re
import shutil
from pathlib import Path
from datetime import datetime, timezone

root = Path(".").resolve()
ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

# ============================================================
# PART 1: claim_layers_utils.py -- negation-awareness patch
# ============================================================
utils_path = root / "scripts" / "shared" / "claim_layers_utils.py"
src = utils_path.read_text(encoding="utf-8")

OLD_BLOCK = """    for match in PRECISE_DECIMAL_PATTERN.finditer(text):
        # check if a source marker exists within reasonable proximity
        window = text[max(0, match.start() - 80):match.end() + 80]
        if not SOURCE_MARKER_PATTERN.search(window):
            flags.append(f"unsourced_precise_decimal:{match.group()}")"""

NEW_BLOCK = """    for match in PRECISE_DECIMAL_PATTERN.finditer(text):
        # check if a source marker exists within reasonable proximity
        window = text[max(0, match.start() - 80):match.end() + 80]
        if NEGATION_MARKER_PATTERN.search(window):
            continue  # Decision #61: skip flag if value is explicitly negated/removed
        if not SOURCE_MARKER_PATTERN.search(window):
            flags.append(f"unsourced_precise_decimal:{match.group()}")"""

if OLD_BLOCK not in src:
    print("[FAIL] OLD_BLOCK not found in claim_layers_utils.py -- aborting, no changes made.")
    raise SystemExit(1)

# Insert the new constant right after PRECISE_DECIMAL_PATTERN definition
CONST_ANCHOR = 'PRECISE_DECIMAL_PATTERN = re.compile(r"\\b\\d+\\.\\d{2,}\\b")'
if CONST_ANCHOR not in src:
    print("[FAIL] PRECISE_DECIMAL_PATTERN constant anchor not found -- aborting.")
    raise SystemExit(1)

NEGATION_CONST = CONST_ANCHOR + """

# Decision #61: negation-awareness for precise-decimal flagging.
# Prevents false positives where a number is explicitly disclaimed/removed
# in the surrounding narrative (e.g. "A previous version hardcoded 0.84
# ... it has been removed.").
NEGATION_MARKER_PATTERN = re.compile(
    r"(has been removed|was removed|no longer includes?|not included|"
    r"without (a |any )?citation|previous version|placeholder value|"
    r"has since been removed|removed (it|this|the value)|was not included|"
    r"does not include)",
    re.IGNORECASE,
)"""

backup_path = utils_path.with_suffix(utils_path.suffix + f".bak.{ts}")
shutil.copy2(utils_path, backup_path)

new_src = src.replace(CONST_ANCHOR, NEGATION_CONST, 1)
new_src = new_src.replace(OLD_BLOCK, NEW_BLOCK, 1)
utils_path.write_text(new_src, encoding="utf-8")

print(f"[OK] claim_layers_utils.py patched. Backup: {backup_path.name}")

# ============================================================
# PART 2: main.py -- content_flags deduplication patch
# ============================================================
main_path = root / "main.py"
mlines = main_path.read_text(encoding="utf-8").splitlines(keepends=True)

extend_idx = None
for i, line in enumerate(mlines):
    if "content_flags.extend(validate_content_flags(layer))" in line:
        extend_idx = i
        break

if extend_idx is None:
    print("[FAIL] extend line not found in main.py -- aborting.")
    raise SystemExit(1)

extend_line = mlines[extend_idx]
extend_indent = len(extend_line) - len(extend_line.lstrip(" "))
loop_indent = extend_indent - 4  # assume standard 4-space nesting

if loop_indent < 0:
    print(f"[FAIL] Unexpected indent ({extend_indent}) on extend line -- aborting.")
    raise SystemExit(1)

# scan forward to find the first line after the loop body
insert_idx = None
for j in range(extend_idx + 1, len(mlines)):
    stripped = mlines[j].strip()
    if stripped == "":
        continue
    this_indent = len(mlines[j]) - len(mlines[j].lstrip(" "))
    if this_indent <= loop_indent:
        insert_idx = j
        break

if insert_idx is None:
    print("[FAIL] Could not locate end of loop in main.py -- aborting.")
    raise SystemExit(1)

dedup_line = (" " * loop_indent) + "content_flags = list(dict.fromkeys(content_flags))  # Decision #61: dedup\n"

# idempotency guard
already_patched = any("list(dict.fromkeys(content_flags))" in l for l in mlines)
if already_patched:
    print("[SKIP] main.py already contains dedup line -- no changes made to main.py.")
else:
    backup_main = main_path.with_suffix(main_path.suffix + f".bak.{ts}")
    shutil.copy2(main_path, backup_main)
    mlines.insert(insert_idx, dedup_line)
    main_path.write_text("".join(mlines), encoding="utf-8")
    print(f"[OK] main.py patched at insertion line {insert_idx+1} (indent={loop_indent}). Backup: {backup_main.name}")

# ============================================================
# PART 3: compile check both files
# ============================================================
import py_compile
for p in (utils_path, main_path):
    try:
        py_compile.compile(str(p), doraise=True)
        print(f"[OK] py_compile passed: {p.name}")
    except py_compile.PyCompileError as e:
        print(f"[FAIL] py_compile FAILED: {p.name}\\n{e}")
