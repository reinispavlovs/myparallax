﻿from pathlib import Path

path = Path("dump_nde_all_candidates.py")
lines = path.read_text(encoding="utf-8").splitlines()

print(f"=== Total lines: {len(lines)} ===")
for i, line in enumerate(lines, start=1):
    low = line.lower()
    if "_tokenize" in low or "tokenize" in low or "query_tokens" in low or "query =" in low or "STOPWORDS" in line:
        print(f"{i}: {line}")
