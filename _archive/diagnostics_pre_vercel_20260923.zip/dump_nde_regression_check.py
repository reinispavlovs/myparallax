﻿import sys
from pathlib import Path
from urllib.parse import quote
import requests, re

root = Path(".").resolve()
sys.path.insert(0, str(root))
import main as m

query = "quantum brain biology consciousness out-of-body experience clinical"
encoded_query = quote(query)
url = f"http://export.arxiv.org/api/query?search_query=all:{encoded_query}&start=0&max_results=5"

print(f"URL: {url}")
r = requests.get(url, timeout=8)
print(f"Status: {r.status_code}, has <entry>: {'<entry>' in r.text}")

entries = r.text.split("<entry>")[1:] if "<entry>" in r.text else []
print(f"Entry count: {len(entries)}")
print("=" * 70)

query_tokens = m.tokenize_arxiv_text(query)
print(f"Query tokens: {query_tokens}")
print("=" * 70)

for idx, entry_block in enumerate(entries):
    title = ""
    summary = ""
    if "<title>" in entry_block:
        title = entry_block.split("<title>")[1].split("</title>")[0]
    if "<summary>" in entry_block:
        summary = entry_block.split("<summary>")[1].split("</summary>")[0]
    combined = re.sub(r"\s+", " ", f"{title} {summary}").strip()
    overlap_count, overlap_ratio, cand_tokens = m.score_arxiv_candidate(query_tokens, combined)
    print(f"[Candidate {idx+1}] overlap={overlap_count}, ratio={round(overlap_ratio,2)}")
    print(f"  title: {title.strip()[:100]}")
    print(f"  matched tokens: {query_tokens & cand_tokens}")
    print()

print("=" * 70)
result = m.select_best_arxiv_candidate(query, entries)
print(f"select_best_arxiv_candidate -> overlap={result['overlap']}, ratio={round(result['ratio'],2)}")
print(f"MIN_ARXIV_OVERLAP_COUNT={m.MIN_ARXIV_OVERLAP_COUNT}, MIN_ARXIV_OVERLAP_RATIO={m.MIN_ARXIV_OVERLAP_RATIO}")
