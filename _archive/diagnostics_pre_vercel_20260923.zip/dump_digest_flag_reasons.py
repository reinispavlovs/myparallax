﻿import json
from pathlib import Path

digest_path = Path("digests/cross_check.json")
data = json.loads(digest_path.read_text(encoding="utf-8"))

# Structure may vary; try common keys
entries = data.get("drafts") or data.get("entries") or data.get("results") or data

if isinstance(entries, list):
    for e in entries:
        topic = e.get("topic_id", "UNKNOWN")
        flags = e.get("flagged_for_review") or e.get("flags") or e.get("content_flags")
        reasons = e.get("flag_reasons") or e.get("review_reasons")
        print(f"--- {topic} ---")
        print("  flagged:", e.get("flagged_for_review", e.get("needs_review")))
        print("  reasons:", reasons)
        print("  hash_ok:", e.get("hash_ok"))
        print("  topic_valid:", e.get("topic_valid"))
        print("  promoted:", e.get("promoted"))
        print("  review_status:", e.get("review_status"))
        print()
else:
    print(json.dumps(data, indent=2, ensure_ascii=False)[:3000])
