﻿import re
from pathlib import Path

path = Path("scripts/promote_drafts.py")
src = path.read_text(encoding="utf-8")

old_line = 'DRAFTS_DIR = REPO_ROOT / "myparallax_repo" / "drafts"'
new_line = 'DRAFTS_DIR = REPO_ROOT / "drafts"'

if old_line not in src:
    print("[SKIP] Old pattern not found — may already be patched.")
else:
    patched = src.replace(old_line, new_line)
    path.write_text(patched, encoding="utf-8", newline="")
    print("[OK] Patched DRAFTS_DIR in promote_drafts.py")
    print("  old:", old_line)
    print("  new:", new_line)
