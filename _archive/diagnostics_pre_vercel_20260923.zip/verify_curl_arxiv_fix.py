﻿import sys
sys.path.insert(0, ".")
from main import fetch_real_arxiv_summary

query = "quantum brain biology consciousness out-of-body experience clinical"
result = fetch_real_arxiv_summary(query)
print(f"found: {result['found']}")
if result['found']:
    print(f"overlap: {result.get('relevance_overlap_count')}, ratio: {result.get('relevance_overlap_ratio')}")
    print(f"text preview: {result['text'][:150]}")
else:
    print(f"note: {result.get('note')}")
