﻿import re
from pathlib import Path

main_path = Path(".").resolve() / "main.py"
text = main_path.read_text(encoding="utf-8")
lines = text.split("\n")

for i in range(29, 55):
    if i < len(lines):
        print(f"L{i+1}: {lines[i]}")
