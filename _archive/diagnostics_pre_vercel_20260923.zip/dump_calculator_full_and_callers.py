﻿import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
CALC_PATH = REPO_ROOT / "scripts" / "topic_weights_calculator.py"

print("=== Full source: scripts/topic_weights_calculator.py ===")
text = CALC_PATH.read_text(encoding="utf-8")
lines = text.splitlines()
for i, l in enumerate(lines):
    print(f"{i+1:4}: {l}")

print("\n=== Searching repo for callers of topic_weights_calculator ===")
targets = ["topic_weights_calculator", "compute_topic_weight_update"]
for py_file in REPO_ROOT.rglob("*.py"):
    if "_archive" in str(py_file) or "_history" in str(py_file) or py_file == CALC_PATH:
        continue
    try:
        content = py_file.read_text(encoding="utf-8")
    except Exception:
        continue
    for tgt in targets:
        if tgt in content:
            for m in re.finditer(re.escape(tgt), content):
                line_no = content[:m.start()].count("\n") + 1
                line_text = content.splitlines()[line_no-1].strip()
                print(f"{py_file.relative_to(REPO_ROOT)}:{line_no}: {line_text}")
