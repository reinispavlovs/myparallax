﻿import re
from pathlib import Path
from datetime import datetime, timezone
import shutil

REPO_ROOT = Path(".").resolve()
digest_path = REPO_ROOT / "digest_generator.py"
src = digest_path.read_text(encoding="utf-8")

marker = '        meta["credibility_score_C_i"] = credibility_score'
if marker not in src:
    print("[ABORT] Could not find exact writeback anchor line. No changes made.")
    raise SystemExit(1)

if 'meta["risk_level"] = risk_level' in src:
    print("[SKIP] risk_level writeback already present. No changes made.")
    raise SystemExit(0)

# Backup first
history_dir = REPO_ROOT / "digests" / "_history"
history_dir.mkdir(parents=True, exist_ok=True)
ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup_path = history_dir / f"digest_generator.py.bak.{ts}"
shutil.copy2(digest_path, backup_path)
print(f"[BACKUP] {backup_path}")

replacement = (
    '        meta["credibility_score_C_i"] = credibility_score\n'
    '        # Persist aggregate risk_level to top-level meta.json so\n'
    '        # promote_drafts.py can read it (fixes silent None -> bump_weight\n'
    '        # miscalculation, and enables index.json risk_level persistence).\n'
    '        meta["risk_level"] = risk_level'
)

new_src = src.replace(marker, replacement, 1)
digest_path.write_text(new_src, encoding="utf-8")
print("[PATCHED] digest_generator.py updated with risk_level writeback.")

# Compile check
import py_compile
try:
    py_compile.compile(str(digest_path), doraise=True)
    print("[OK] py_compile check passed.")
except py_compile.PyCompileError as e:
    print(f"[FAIL] py_compile error: {e}")
    print("[ROLLBACK] Restoring from backup.")
    shutil.copy2(backup_path, digest_path)
