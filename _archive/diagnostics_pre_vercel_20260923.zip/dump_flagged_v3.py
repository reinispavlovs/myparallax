﻿import json
from pathlib import Path

data = json.loads(Path("digests/cross_check.json").read_text(encoding="utf-8"))
entries = data.get("entries", [])
flagged_ids = data.get("flagged_for_review", [])

print(f"Total entries: {len(entries)}")
print(f"Flagged for review (top-level list): {len(flagged_ids)}")
if flagged_ids:
    print(f"Flagged IDs: {flagged_ids}")

print("\n=== Per-entry detail ===")
for e in entries:
    tid = e.get("topic_id", e.get("content_file"))
    tv = e.get("topic_valid")
    hash_ok = e.get("hash_ok")
    ci = e.get("credibility_score_C_i")
    print(f"{tid}: topic_valid={tv} hash_ok={hash_ok} C_i={ci}")
