﻿import re
from pathlib import Path

src = Path("scripts/promote_drafts.py").read_text(encoding="utf-8")
lines = src.splitlines()

for i, line in enumerate(lines, 1):
    if "cross_check" in line or "approved" in line.lower() or "review_status" in line:
        print(f"{i:4}: {line}")
