﻿import json
from pathlib import Path

REPO_ROOT = Path(".").resolve()
cc = json.loads((REPO_ROOT / "digests" / "cross_check.json").read_text(encoding="utf-8"))

print("Total entries:", len(cc.get("entries", [])))
print("Flagged for review:", cc.get("flagged_for_review"))
for e in cc.get("entries", []):
    print(e.get("topic_id"), "-> current_topic_weight:", e.get("current_topic_weight"))

tw = json.loads((REPO_ROOT / "content" / "articles" / "topic_weights.json").read_text(encoding="utf-8"))
print("\ntopic_weights.json top-level keys:", list(tw.keys()))
