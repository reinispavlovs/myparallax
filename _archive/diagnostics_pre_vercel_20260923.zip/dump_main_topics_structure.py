﻿from pathlib import Path
import re

src = Path("main.py").read_text(encoding="utf-8")
lines = src.splitlines()
for i, line in enumerate(lines):
    if re.search(r"^\s*TOPICS\s*=", line):
        start = i
        # print until closing bracket found, up to 40 lines
        end = min(len(lines), i + 40)
        for j in range(start, end):
            print(f"{j+1}: {lines[j]}")
            if lines[j].strip() == "]" and j > start:
                break
        break
