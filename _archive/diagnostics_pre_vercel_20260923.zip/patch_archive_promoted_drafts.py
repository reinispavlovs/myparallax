﻿import shutil
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(".").resolve()
target = REPO_ROOT / "scripts" / "promote_drafts.py"
backup_dir = REPO_ROOT / "digests" / "_history"
backup_dir.mkdir(parents=True, exist_ok=True)
ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup_path = backup_dir / f"promote_drafts.py.bak.{ts}"

src = target.read_text(encoding="utf-8")
shutil.copy2(target, backup_path)
print("[BACKUP]", backup_path.relative_to(REPO_ROOT))

src = src.replace("myparallax_repo/drafts/", "drafts/")

anchor_const = "WEIGHTS_PATH = ARTICLES_DIR / \"topic_weights.json\"\n"
if anchor_const not in src:
    raise SystemExit("[FAIL] could not find WEIGHTS_PATH anchor line")
new_const_block = anchor_const + "PROMOTED_ARCHIVE_DIR = DRAFTS_DIR / \"_promoted\"\n"
src = src.replace(anchor_const, new_const_block, 1)

anchor_save = "    meta[\"promoted_at\"] = datetime.now(timezone.utc).isoformat()\n    save_meta(meta_path, meta)\n"
if anchor_save not in src:
    raise SystemExit("[FAIL] could not find save_meta anchor block")

lines = []
lines.append(anchor_save)
lines.append("\n")
lines.append("    # 6. Archive the promoted draft files out of the active drafts/ folder\n")
lines.append("    #    to prevent directory pollution and stale batch-conflict false positives\n")
lines.append("    #    in digest_generator.py on subsequent runs.\n")
lines.append("    PROMOTED_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)\n")
lines.append("    archived_html = PROMOTED_ARCHIVE_DIR / html_path.name\n")
lines.append("    archived_meta = PROMOTED_ARCHIVE_DIR / meta_path.name\n")
lines.append("    try:\n")
lines.append("        shutil.move(str(html_path), str(archived_html))\n")
lines.append("        shutil.move(str(meta_path), str(archived_meta))\n")
lines.append("        print(\"  archived draft ->\", archived_html.name, \"(+ .meta.json)\")\n")
lines.append("    except OSError as e:\n")
lines.append("        print(\"  [WARN] promotion succeeded but archiving failed:\", e)\n")
lines.append("        print(\"  Draft remains in drafts/ but is marked promoted=True (idempotent).\")\n")
archive_block = "".join(lines)

src = src.replace(anchor_save, archive_block, 1)

target.write_text(src, encoding="utf-8", newline="")
print("[OK] patch applied.")

import py_compile
py_compile.compile(str(target), doraise=True)
print("[OK] py_compile passed.")
