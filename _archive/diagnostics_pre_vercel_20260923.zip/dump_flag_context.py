﻿from pathlib import Path

path = Path("digest_generator.py")
text = path.read_text(encoding="utf-8")
lines = text.splitlines()

for i, line in enumerate(lines, start=1):
    if "flag" in line.lower() and ("drift" in line.lower() or "stored" in line.lower() or "recompute" in line.lower() or "sorted(set" in line.lower() or "content_flags" in line.lower()):
        start = max(0, i-3)
        end = min(len(lines), i+3)
        print(f"--- context around line {i} ---")
        for j in range(start, end):
            print(f"{j+1}: {lines[j]}")
        print()
