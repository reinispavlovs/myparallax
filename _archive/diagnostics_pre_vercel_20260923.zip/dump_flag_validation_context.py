﻿import re
from pathlib import Path

REPO_ROOT = Path(".").resolve()
main_path = REPO_ROOT / "main.py"
utils_path = REPO_ROOT / "scripts" / "shared" / "claim_layers_utils.py"

main_src = main_path.read_text(encoding="utf-8")
utils_src = utils_path.read_text(encoding="utf-8")

print("=" * 70)
print("[1] validate_content_flags() in main.py")
print("=" * 70)
idx = main_src.find("def validate_content_flags")
if idx != -1:
    snippet = main_src[idx:idx+2000]
    print(snippet)
else:
    print("[NOT FOUND] validate_content_flags not in main.py")

print()
print("=" * 70)
print("[2] PRECISE_DECIMAL_PATTERN definition + usage in claim_layers_utils.py")
print("=" * 70)
for m in re.finditer(r"PRECISE_DECIMAL_PATTERN", utils_src):
    start = max(0, m.start() - 100)
    end = min(len(utils_src), m.start() + 300)
    print(f"--- match at offset {m.start()} ---")
    print(utils_src[start:end])
    print()

print("=" * 70)
print("[3] content_flags list construction in main.py")
print("=" * 70)
for m in re.finditer(r"content_flags", main_src):
    start = max(0, m.start() - 80)
    end = min(len(main_src), m.start() + 150)
    print(f"--- offset {m.start()} ---")
    print(main_src[start:end].replace(chr(10), " | "))
    print()
