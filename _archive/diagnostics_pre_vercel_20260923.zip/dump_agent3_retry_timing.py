﻿import re
from pathlib import Path

main_py = Path(".").resolve() / "main.py"
text = main_py.read_text(encoding="utf-8")
lines = text.splitlines()

print(f"main.py total lines: {len(lines)}")
print("--- Lines 245-265 (Agent 3 retry block) ---")
for i, line in enumerate(lines[244:265], start=245):
    print(f"{i}: {line}")

print()
print("--- Grep for timeout= ---")
for i, line in enumerate(lines, start=1):
    if "timeout" in line.lower() or "retries" in line.lower() or "backoff" in line.lower() or "sleep" in line.lower():
        print(f"{i}: {line.strip()}")
