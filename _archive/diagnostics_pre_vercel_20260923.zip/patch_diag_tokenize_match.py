﻿import re
from pathlib import Path

path = Path("dump_nde_all_candidates.py")
src = path.read_text(encoding="utf-8")

old_block = '''def _tokenize(s):
    s = s.lower()
    s = re.sub(r"[^a-z0-9\\s-]", " ", s)
    s = s.replace("-", " ")
    return {t for t in s.split() if t and t not in STOPWORDS}'''

new_block = '''def _tokenize(s):
    s = s.lower()
    s = s.replace("out-of-body", " outofbodyanchor ")
    s = s.replace("out of body", " outofbodyanchor ")
    s = s.replace("near-death", " neardeathanchor ")
    s = s.replace("near death", " neardeathanchor ")
    s = re.sub(r"[^a-z0-9\\s-]", " ", s)
    s = s.replace("-", " ")
    return {t for t in s.split() if t and t not in STOPWORDS}'''

if old_block not in src:
    print("[FAIL] Exact block not found, dumping lines 10-18 for manual inspection:")
    lines = src.splitlines()
    for i, line in enumerate(lines[9:18], start=10):
        print(f"{i}: {repr(line)}")
    raise SystemExit(1)

src = src.replace(old_block, new_block, 1)
path.write_text(src, encoding="utf-8")
print("[OK] Patched diagnostic script _tokenize to match main.py phrase-anchor logic.")
