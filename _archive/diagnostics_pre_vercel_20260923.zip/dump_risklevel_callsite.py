﻿import re
from pathlib import Path

REPO_ROOT = Path(".").resolve()
digest_path = REPO_ROOT / "digest_generator.py"
digest_src = digest_path.read_text(encoding="utf-8")

print("=" * 70)
print("[1] All call sites of aggregate_risk_level(")
print("=" * 70)
nl = chr(10)
sep = " | "
for m in re.finditer(r"aggregate_risk_level\(", digest_src):
    start = max(0, m.start() - 150)
    end = min(len(digest_src), m.start() + 150)
    print(f"offset {m.start()}: ...{digest_src[start:end].replace(nl, sep)}...")
    print()

print("=" * 70)
print("[2] Backup directory conventions - check for _history folders")
print("=" * 70)
for p in [REPO_ROOT / "_history", REPO_ROOT / "scripts" / "shared" / "_history", REPO_ROOT / "digests" / "_history"]:
    print(f"{p}: exists={p.exists()}")
