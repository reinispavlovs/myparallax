﻿import re
from pathlib import Path

path = Path("digest_generator.py")
text = path.read_text(encoding="utf-8")

old = '''        recomputed_flags = list(dict.fromkeys(recomputed_flags_raw))
        stored_flags = meta.get("content_flags", [])
        if sorted(recomputed_flags) != sorted(stored_flags):'''

new = '''        recomputed_flags = list(dict.fromkeys(recomputed_flags_raw))
        stored_flags = meta.get("content_flags", [])
        # Both main.py (at generation) and this recompute can legitimately
        # emit the SAME flag once per claim layer that trips it — duplicate
        # counts are a function of layer topology, not content drift.
        # Compare deduplicated SETS on both sides; only a flag type being
        # added or removed indicates real drift worth a human's attention.
        if sorted(set(recomputed_flags)) != sorted(set(stored_flags)):'''

if old not in text:
    raise SystemExit("PATCH FAILED: exact block not found — aborting without writing.")

text = text.replace(old, new, 1)
path.write_text(text, encoding="utf-8", newline="")
print("Patched OK.")
