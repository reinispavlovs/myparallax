﻿from pathlib import Path

REPO_ROOT = Path(".").resolve()
target = REPO_ROOT / "scripts" / "promote_drafts.py"
lines = target.read_text(encoding="utf-8").splitlines()

print("--- Lines 1-70 (imports + path constants) ---")
for i in range(0, min(70, len(lines))):
    print(f"{i+1}: {lines[i]}")
