﻿from pathlib import Path

path = Path("scripts/promote_drafts.py")
text = path.read_text(encoding="utf-8")
lines = text.splitlines()

for i, line in enumerate(lines, start=1):
    if "credibility_score_C_i" in line or "score_guard" in line.lower() or "old_c_i" in line.lower() or "new_c_i" in line.lower():
        start = max(0, i-3)
        end = min(len(lines), i+3)
        print(f"--- context around line {i} ---")
        for j in range(start, end):
            print(f"{j+1}: {lines[j]}")
        print()
