﻿import re
from pathlib import Path

text = Path("digest_generator.py").read_text(encoding="utf-8")
lines = text.splitlines()
for i, line in enumerate(lines):
    if "recomputed_flags_raw = []" in line or "recomputed_flags = list(dict.fromkeys" in line:
        start = max(0, i-2)
        end = min(len(lines), i+12)
        print("\n".join(f"{n+1}: {l}" for n, l in enumerate(lines[start:end], start=start)))
        print("---")
