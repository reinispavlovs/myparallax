﻿from pathlib import Path

src = Path("scripts/promote_drafts.py").read_text(encoding="utf-8")
lines = src.splitlines()

for i, line in enumerate(lines, 1):
    if "DRAFTS_DIR" in line or "REPO_ROOT" in line or "BASE_DIR" in line:
        print(f"{i:4}: {line}")

print("---LIVE CHECK---")
import importlib.util
spec = importlib.util.spec_from_file_location("promote_drafts", "scripts/promote_drafts.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
print("DRAFTS_DIR =", mod.DRAFTS_DIR)
print("Exists:", mod.DRAFTS_DIR.exists())
print("Glob count:", len(list(mod.DRAFTS_DIR.glob("*.meta.json"))))
