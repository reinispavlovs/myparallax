﻿import re
import shutil
import py_compile
from pathlib import Path
from datetime import datetime, timezone

root = Path(".").resolve()
main_path = root / "main.py"

lines = main_path.read_text(encoding="utf-8").splitlines(keepends=True)

# Locate function boundaries dynamically (same logic as diagnostic dump)
start = None
for i, line in enumerate(lines):
    if line.strip().startswith("def fetch_real_arxiv_summary"):
        start = i
        break

if start is None:
    raise SystemExit("[FAIL] fetch_real_arxiv_summary not found - aborting, no changes made.")

end = start + 1
while end < len(lines):
    if lines[end].startswith("def ") and end > start + 1:
        break
    end += 1

print(f"[INFO] Replacing lines {start+1} to {end} (0-indexed slice [{start}:{end}])")

# Backup first
hist_dir = root / "_history"
hist_dir.mkdir(exist_ok=True)
ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup_path = hist_dir / f"main.py.bak.{ts}"
shutil.copy2(main_path, backup_path)
print(f"[INFO] Backup created: {backup_path}")

REPLACEMENT = '''# --- Module-level arXiv relevance filtering (Decision #105 refactor) ---
# Extracted from fetch_real_arxiv_summary()'s nested scope so tokenization
# and scoring logic can be imported directly by diagnostic/test scripts
# instead of being duplicated (see Decision #230/#231 architectural debt).

ARXIV_STOPWORDS = {
    "a", "an", "the", "of", "in", "on", "and", "or", "to",
    "for", "with", "at", "by",
}

# Multi-word phrases treated as a single semantic unit to avoid false
# lexical overlap with unrelated terms (e.g. "out-of-body" vs. "many-body
# problem"). See Decision #223/#224/#228.
PHRASE_ANCHORS = [
    ("out-of-body", "outofbodyanchor"),
    ("out of body", "outofbodyanchor"),
    ("near-death", "neardeathanchor"),
    ("near death", "neardeathanchor"),
]

MIN_ARXIV_OVERLAP_COUNT = 2
MIN_ARXIV_OVERLAP_RATIO = 0.34


def tokenize_arxiv_text(s: str) -> set:
    """Lowercases, applies phrase-anchor substitution, strips punctuation,
    and returns a stopword-filtered token set. Module-level per Decision #105
    so it can be imported directly by tests/diagnostics."""
    s = s.lower()
    for phrase, anchor in PHRASE_ANCHORS:
        s = s.replace(phrase, f" {anchor} ")
    s = re.sub(r"[^a-z0-9\\s-]", " ", s)
    s = s.replace("-", " ")
    return {t for t in s.split() if t and t not in ARXIV_STOPWORDS}


def score_arxiv_candidate(query_tokens: set, candidate_text: str) -> tuple:
    """Returns (overlap_count, overlap_ratio, candidate_tokens) for a single
    candidate string against the query token set."""
    candidate_tokens = tokenize_arxiv_text(candidate_text)
    overlap = query_tokens & candidate_tokens
    overlap_count = len(overlap)
    overlap_ratio = overlap_count / len(query_tokens) if query_tokens else 0.0
    return overlap_count, overlap_ratio, candidate_tokens


def select_best_arxiv_candidate(query: str, entries: list) -> dict:
    """Parses raw arXiv <entry> blocks, scores each by keyword overlap
    against the query, and returns the best candidate. Pure function:
    no network I/O, fully testable in isolation.

    Returns dict with keys: text (str|None), overlap (int), ratio (float).
    """
    query_tokens = tokenize_arxiv_text(query)
    best = None
    best_overlap = 0
    best_ratio = 0.0
    for entry_block in entries:
        title = ""
        summary = ""
        if "<title>" in entry_block:
            title = entry_block.split("<title>")[1].split("</title>")[0]
        if "<summary>" in entry_block:
            summary = entry_block.split("<summary>")[1].split("</summary>")[0]
        combined = re.sub(r"\\s+", " ", f"{title} {summary}").strip()
        if len(combined) <= 20:
            continue
        overlap_count, overlap_ratio, _ = score_arxiv_candidate(query_tokens, combined)
        if overlap_count > best_overlap or (overlap_count == best_overlap and overlap_ratio > best_ratio):
            best = combined
            best_overlap = overlap_count
            best_ratio = overlap_ratio
    return {"text": best, "overlap": best_overlap, "ratio": best_ratio}


def fetch_real_arxiv_summary(query: str) -> dict:
    """Fetches a real recent paper summary from the open arXiv API.
    Returns a dict with 'text' and 'found' (bool) so downstream code
    never confuses fallback text with a real citation.

    Relevance filter: arXiv's 'all:' search field ranks poorly on
    multi-keyword queries, sometimes returning topically unrelated
    papers (e.g. Mediterranean fire ecology for a precession query).
    Fetches up to 5 candidates and scores each by keyword overlap,
    picking the best match. If no candidate clears the relevance
    threshold, returns found=False rather than a misleading source.

    Tokenization/scoring logic lives in module-level helpers
    (tokenize_arxiv_text, score_arxiv_candidate, select_best_arxiv_candidate)
    per Decision #105, importable independently for tests/diagnostics.
    """
    encoded_query = quote(query)
    url = f"http://export.arxiv.org/api/query?search_query=all:{encoded_query}&start=0&max_results=5"
    try:
        r = requests.get(url, timeout=8)
        if r.status_code == 200 and "<entry>" in r.text:
            entries = r.text.split("<entry>")[1:]
            result = select_best_arxiv_candidate(query, entries)
            best = result["text"]
            best_overlap = result["overlap"]
            best_ratio = result["ratio"]

            if best is not None and best_overlap >= MIN_ARXIV_OVERLAP_COUNT and best_ratio >= MIN_ARXIV_OVERLAP_RATIO:
                return {
                    "text": best[:400],
                    "found": True,
                    "raw_query": query,
                    "relevance_overlap_count": best_overlap,
                    "relevance_overlap_ratio": round(best_ratio, 2),
                }
            else:
                return {
                    "text": None,
                    "found": False,
                    "raw_query": query,
                    "note": (
                        "NO_RELEVANT_SOURCE_FOUND \\u2014 best candidate failed keyword relevance "
                        f"threshold (overlap={best_overlap}, ratio={round(best_ratio, 2)}); a human "
                        "must manually add a citation before publication."
                    ),
                }
    except Exception as e:
        print(f"[!] arXiv request failed: {e}")

    return {
        "text": None,
        "found": False,
        "raw_query": query,
        "note": "NO_SOURCE_FOUND \\u2014 a human must manually add a citation before publication.",
    }

'''

new_lines = lines[:start] + [REPLACEMENT] + lines[end:]
main_path.write_text("".join(new_lines), encoding="utf-8")

try:
    py_compile.compile(str(main_path), doraise=True)
    print("[OK] main.py compiled successfully after refactor.")
except py_compile.PyCompileError as e:
    print("[FAIL] Compile error - restoring backup.")
    shutil.copy2(backup_path, main_path)
    print(e)
    raise SystemExit(1)

print("[DONE] Task #105 refactor applied.")
