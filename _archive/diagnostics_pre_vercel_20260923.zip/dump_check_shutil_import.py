﻿from pathlib import Path

target = Path(".").resolve() / "scripts" / "promote_drafts.py"
lines = target.read_text(encoding="utf-8").splitlines()

found = False
for i, line in enumerate(lines):
    if "import shutil" in line:
        print(f"[FOUND] line {i+1}: {line}")
        found = True

if not found:
    print("[MISSING] 'import shutil' not found anywhere in the file")
