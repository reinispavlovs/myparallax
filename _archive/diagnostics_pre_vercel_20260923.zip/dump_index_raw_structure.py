﻿import json
from pathlib import Path

REPO_ROOT = Path(".").resolve()
INDEX_PATH = REPO_ROOT / "content" / "articles" / "index.json"

with open(INDEX_PATH, "r", encoding="utf-8") as f:
    index_data = json.load(f)

print("=== schema key ===")
print(json.dumps(index_data.get("schema"), indent=2))

print("\n=== topics structure (raw dump) ===")
print(json.dumps(index_data.get("topics"), indent=2, default=str))
