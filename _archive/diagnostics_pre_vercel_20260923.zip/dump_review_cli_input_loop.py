﻿import pathlib

REPO_ROOT = pathlib.Path(__file__).resolve().parent
review_cli_path = REPO_ROOT / "scripts" / "review_cli.py"

with open(review_cli_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

print(f"Total lines in review_cli.py: {len(lines)}\n")

# Find the input loop / decision prompt section
target_markers = ["approve", "reject", "skip", "quit", "view", "input(", "elif", "while True"]

start_idx = None
for i, line in enumerate(lines):
    if "[a]pprove" in line or "approve / [r]eject" in line.lower() or "a, r, s, or q" in line:
        start_idx = i
        break

if start_idx is None:
    print("Could not locate prompt string. Dumping full file with line numbers instead.")
    for i, line in enumerate(lines, start=1):
        print(f"{i:4}: {line}", end="")
else:
    # Print generous context: 40 lines before, 60 after
    lo = max(0, start_idx - 40)
    hi = min(len(lines), start_idx + 60)
    print(f"--- Context lines {lo+1} to {hi} ---\n")
    for i in range(lo, hi):
        print(f"{i+1:4}: {lines[i]}", end="")
