﻿import json
from pathlib import Path

data = json.loads(Path("digests/cross_check.json").read_text(encoding="utf-8"))
entries = data.get("drafts", data if isinstance(data, list) else [])

flagged = 0
for e in entries:
    tv = e.get("topic_valid")
    flags = e.get("content_flags", [])
    needs_review = e.get("needs_manual_review", e.get("flagged_for_review"))
    if needs_review or tv is False:
        flagged += 1
        print(f"[FLAGGED] {e.get('topic_id', e.get('content_file'))} topic_valid={tv} flags={flags}")

print(f"\nTotal flagged: {flagged}")
print(f"Total entries: {len(entries)}")
