﻿import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

main_py = Path("main.py")
backup_dir = Path("content/articles/_history")
backup_dir.mkdir(parents=True, exist_ok=True)
ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup_path = backup_dir / f"main.py.bak.{ts}"
shutil.copy2(main_py, backup_path)
print(f"[OK] Backup created: {backup_path}")

text = main_py.read_text(encoding="utf-8")

# --- Fix 1: switch arXiv URL scheme from http to https ---
old_url_line = 'url = f"http://export.arxiv.org/api/query?search_query=all:{encoded_query}&start=0&max_results=5"'
new_url_line = 'url = f"https://export.arxiv.org/api/query?search_query=all:{encoded_query}&start=0&max_results=5"'
if old_url_line in text:
    text = text.replace(old_url_line, new_url_line, 1)
    print("[OK] Switched arXiv query URL from http:// to https://")
elif new_url_line in text:
    print("[SKIP] URL already uses https://")
else:
    print("[WARN] Could not locate the exact url f-string line \u2014 no URL change made")

# --- Fix 2: add -L (follow redirects) to curl.exe call as defense-in-depth ---
old_curl_cmd = '["curl.exe", "-s", "-w", "\\n%{http_code}", url]'
new_curl_cmd = '["curl.exe", "-s", "-L", "-w", "\\n%{http_code}", url]'
if old_curl_cmd in text:
    text = text.replace(old_curl_cmd, new_curl_cmd, 1)
    print("[OK] Added -L (follow redirects) flag to curl.exe call")
elif new_curl_cmd in text:
    print("[SKIP] -L flag already present")
else:
    print("[WARN] Could not locate curl.exe subprocess.run argument list \u2014 no -L flag added")

main_py.write_text(text, encoding="utf-8")
print("[OK] main.py written")

result = subprocess.run([sys.executable, "-m", "py_compile", str(main_py)], capture_output=True, text=True)
if result.returncode == 0:
    print("[OK] py_compile passed")
else:
    print("[FAIL] py_compile errors:")
    print(result.stdout)
    print(result.stderr)
    sys.exit(1)
