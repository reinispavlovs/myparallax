﻿import datetime as _dt
from pathlib import Path

REPO_ROOT = Path(".").resolve()
DG_PATH = REPO_ROOT / "digest_generator.py"
src = DG_PATH.read_text(encoding="utf-8")

old_block = """        # 7. Current topic weight lookup (best-effort match by id/name)
        current_weight = None
        for t in topic_weights.get("topics", {}).values():
            if t.get("id") == topic_id or topic_id in t.get("name", "").lower().replace(" ", "_"):
                current_weight = t.get("current_weight")
                break"""

new_block = """        # 7. Current topic weight lookup -- reads the LIVE flat schema
        # ({topic_id}: float), which is the only schema actively written by
        # promote_drafts.py::bump_weight(). The nested topics.{id}.current_weight
        # structure was legacy seed data and has been removed from
        # topic_weights.json (cleanup 2026-09-21).
        current_weight = topic_weights.get(topic_id)
        if not isinstance(current_weight, (int, float)):
            current_weight = None"""

if old_block not in src:
    print("[ABORT] Expected block not found verbatim -- no changes made.")
else:
    ts = _dt.datetime.now().strftime("%Y%m%dT%H%M%SZ")
    backup = REPO_ROOT / "digests" / "_history" / ("digest_generator.py.bak.weightfix." + ts)
    backup.write_text(src, encoding="utf-8")
    new_src = src.replace(old_block, new_block)
    DG_PATH.write_text(new_src, encoding="utf-8", newline="")
    print("[OK] Patched. Backup at " + str(backup))
