﻿import sys
from pathlib import Path

sys.path.insert(0, str(Path(".").resolve()))

from main import fetch_real_arxiv_summary

result = fetch_real_arxiv_summary("quantum brain biology consciousness out-of-body experience clinical")
print(f"Found: {result['found']}")
print(f"Overlap count: {result.get('relevance_overlap_count')}")
print(f"Overlap ratio: {result.get('relevance_overlap_ratio')}")
print(f"\nFull text (400 chars):\n{result['text']}")
