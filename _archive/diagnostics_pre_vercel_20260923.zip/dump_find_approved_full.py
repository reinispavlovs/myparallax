﻿from pathlib import Path

src = Path("scripts/promote_drafts.py").read_text(encoding="utf-8")
lines = src.splitlines()

for i in range(125, 175):
    if i < len(lines):
        print(f"{i+1:4}: {lines[i]}")
