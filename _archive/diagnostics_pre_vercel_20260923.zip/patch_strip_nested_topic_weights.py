﻿import json
import datetime as _dt
from pathlib import Path

REPO_ROOT = Path(".").resolve()
TW_PATH = REPO_ROOT / "content" / "articles" / "topic_weights.json"

data = json.loads(TW_PATH.read_text(encoding="utf-8"))

if "topics" not in data:
    print("[SKIP] No nested topics key present -- already clean.")
else:
    ts = _dt.datetime.now().strftime("%Y%m%dT%H%M%SZ")
    backup_dir = REPO_ROOT / "digests" / "_history"
    backup_dir.mkdir(parents=True, exist_ok=True)
    backup_path = backup_dir / ("topic_weights.json.bak." + ts)
    backup_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    removed = data.pop("topics")
    TW_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8", newline="")

    print("[OK] Removed nested topics key (" + str(len(removed)) + " entries).")
    print("[OK] Backup written to " + str(backup_path))
    print("[OK] Remaining top-level keys: " + ", ".join(data.keys()))
