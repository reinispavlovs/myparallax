﻿import pathlib
p = pathlib.Path("scripts/review_cli.py").resolve()
lines = p.read_text(encoding="utf-8").splitlines()
print(lines[35])  # line 36, 0-indexed
