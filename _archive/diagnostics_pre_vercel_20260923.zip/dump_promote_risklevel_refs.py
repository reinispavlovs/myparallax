﻿import re
from pathlib import Path

REPO_ROOT = Path(".").resolve()
promote_path = REPO_ROOT / "scripts" / "promote_drafts.py"
promote_src = promote_path.read_text(encoding="utf-8")

print("=" * 70)
print("[1] All references to risk_level in promote_drafts.py")
print("=" * 70)
nl = chr(10)
sep = " | "
for m in re.finditer(r"risk_level", promote_src):
    start = max(0, m.start() - 120)
    end = min(len(promote_src), m.start() + 120)
    print(f"offset {m.start()}: ...{promote_src[start:end].replace(nl, sep)}...")
    print()
