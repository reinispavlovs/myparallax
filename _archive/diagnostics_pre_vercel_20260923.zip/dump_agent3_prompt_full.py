﻿from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
main_path = REPO_ROOT / "main.py"

with open(main_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

print("=== Lines 194-262 (full Agent 3 function: prompt build -> API call -> retry) ===")
for i in range(193, 262):
    if i < len(lines):
        print(f"{i+1:4}: {lines[i]}", end="")
