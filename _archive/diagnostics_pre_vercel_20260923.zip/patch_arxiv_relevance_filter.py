﻿import re
from pathlib import Path
from datetime import datetime, timezone

main_path = Path(".").resolve() / "main.py"
text = main_path.read_text(encoding="utf-8")

# Backup
ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup_dir = Path(".").resolve() / "_history"
backup_dir.mkdir(exist_ok=True)
backup_path = backup_dir / f"main.py.bak.{ts}"
backup_path.write_text(text, encoding="utf-8")
print(f"[BACKUP] {backup_path}")

# Locate function span: from def fetch_real_arxiv_summary to next top-level def
start_marker = "def fetch_real_arxiv_summary(query: str) -> dict:"
end_marker = "\ndef agent_1_multi_source_simulation(topic):"

start_idx = text.find(start_marker)
end_idx = text.find(end_marker)

if start_idx == -1 or end_idx == -1:
    print("[FAIL] Could not locate function boundaries. No changes made.")
    raise SystemExit(1)

if end_idx <= start_idx:
    print("[FAIL] end_marker found before start_marker. Aborting.")
    raise SystemExit(1)

old_block = text[start_idx:end_idx]
print(f"[OK] Located function block: {len(old_block)} chars")

NEW_FUNC = '''def fetch_real_arxiv_summary(query: str) -> dict:
    """Fetches a real recent paper summary from the open arXiv API.
    Returns a dict with 'text' and 'found' (bool) so downstream code
    never confuses fallback text with a real citation.

    Relevance filter: arXiv's 'all:' search field ranks poorly on
    multi-keyword queries, sometimes returning topically unrelated
    papers (e.g. Mediterranean fire ecology for a precession query).
    This function fetches up to 5 candidates and scores each by
    keyword overlap between the query and the candidate's title+summary,
    picking the best match. If no candidate clears the relevance
    threshold, it returns found=False rather than a misleading source.
    """
    STOPWORDS = {"a", "an", "the", "of", "in", "on", "and", "or", "to",
                 "for", "with", "at", "by"}

    def _tokenize(s: str) -> set:
        s = s.lower()
        s = re.sub(r"[^a-z0-9\\s-]", " ", s)
        s = s.replace("-", " ")
        return {t for t in s.split() if t and t not in STOPWORDS}

    query_tokens = _tokenize(query)
    MIN_OVERLAP_COUNT = 2
    MIN_OVERLAP_RATIO = 0.34

    encoded_query = quote(query)
    url = f"http://export.arxiv.org/api/query?search_query=all:{encoded_query}&start=0&max_results=5"
    try:
        r = requests.get(url, timeout=8)
        if r.status_code == 200 and "<entry>" in r.text:
            entries = r.text.split("<entry>")[1:]
            best = None
            best_overlap = 0
            best_ratio = 0.0
            for entry_block in entries:
                title = ""
                summary = ""
                if "<title>" in entry_block:
                    title = entry_block.split("<title>")[1].split("</title>")[0]
                if "<summary>" in entry_block:
                    summary = entry_block.split("<summary>")[1].split("</summary>")[0]
                combined = re.sub(r"\\s+", " ", f"{title} {summary}").strip()
                if len(combined) <= 20:
                    continue
                candidate_tokens = _tokenize(combined)
                overlap = query_tokens & candidate_tokens
                overlap_count = len(overlap)
                overlap_ratio = overlap_count / len(query_tokens) if query_tokens else 0.0
                if overlap_count > best_overlap or (overlap_count == best_overlap and overlap_ratio > best_ratio):
                    best = combined
                    best_overlap = overlap_count
                    best_ratio = overlap_ratio

            if best is not None and best_overlap >= MIN_OVERLAP_COUNT and best_ratio >= MIN_OVERLAP_RATIO:
                return {
                    "text": best[:400],
                    "found": True,
                    "raw_query": query,
                    "relevance_overlap_count": best_overlap,
                    "relevance_overlap_ratio": round(best_ratio, 2),
                }
            else:
                return {
                    "text": None,
                    "found": False,
                    "raw_query": query,
                    "note": (
                        "NO_RELEVANT_SOURCE_FOUND \\u2014 best candidate failed keyword relevance "
                        f"threshold (overlap={best_overlap}, ratio={round(best_ratio, 2)}); a human "
                        "must manually add a citation before publication."
                    ),
                }
    except Exception as e:
        print(f"[!] arXiv request failed: {e}")

    return {
        "text": None,
        "found": False,
        "raw_query": query,
        "note": "NO_SOURCE_FOUND \\u2014 a human must manually add a citation before publication.",
    }

'''

new_text = text[:start_idx] + NEW_FUNC + text[end_idx + 1:]
main_path.write_text(new_text, encoding="utf-8")
print(f"[OK] Patched {main_path} (relevance-filtered fetch_real_arxiv_summary)")

# Compile check
import py_compile
try:
    py_compile.compile(str(main_path), doraise=True)
    print("[OK] main.py compiles successfully.")
except py_compile.PyCompileError as e:
    print(f"[FAIL] Compile error: {e}")
