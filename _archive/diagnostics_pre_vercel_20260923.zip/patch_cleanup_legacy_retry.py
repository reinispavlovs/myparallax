﻿import shutil
import stat
import time
from pathlib import Path

legacy = Path("myparallax_repo")

if not legacy.exists():
    print("myparallax_repo/ already gone (partial deletion succeeded). Nothing to do.")
else:
    remaining = list(legacy.rglob("*"))
    print(f"Remaining items after failed rmtree: {len(remaining)}")
    for item in remaining:
        try:
            st = item.stat()
            readonly = not (st.st_mode & stat.S_IWRITE)
            print(f"  {'DIR ' if item.is_dir() else 'FILE'} readonly={readonly}  {item}")
        except Exception as e:
            print(f"  ERROR stat-ing {item}: {e}")

    def clear_readonly(path):
        for p in Path(path).rglob("*"):
            try:
                p.chmod(stat.S_IWRITE)
            except Exception:
                pass

    def onexc_handler(func, path, exc_info):
        try:
            Path(path).chmod(stat.S_IWRITE)
            func(path)
        except Exception as e:
            print(f"  Retry failed for {path}: {e}")

    print("\nClearing read-only attributes and retrying deletion (up to 5 attempts, OneDrive lock backoff)...")
    for attempt in range(1, 6):
        if not legacy.exists():
            print(f"Deleted successfully on attempt {attempt}.")
            break
        clear_readonly(legacy)
        try:
            shutil.rmtree(legacy, onexc=onexc_handler)
        except Exception as e:
            print(f"Attempt {attempt} raised: {type(e).__name__}: {e}")
        if legacy.exists():
            print(f"Attempt {attempt}: still exists, waiting 2s (possible OneDrive lock)...")
            time.sleep(2)
        else:
            print(f"Deleted successfully on attempt {attempt}.")
            break

    if legacy.exists():
        print("\nFAILED: myparallax_repo/ still exists after 5 attempts.")
        print("Archive is safe at _archive\\myparallax_repo_legacy_20260921T184352Z.zip")
        print("Manual deletion or a machine restart (to release OneDrive/indexer locks) may be required.")
    else:
        print("\nCleanup complete. myparallax_repo/ removed.")
