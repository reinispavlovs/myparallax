﻿import requests

url = "https://export.arxiv.org/api/query?search_query=all:quantum&start=0&max_results=1&_cb=88888"

print("=" * 70)
print("TEST A: Explicit Accept: application/atom+xml")
print("=" * 70)
r = requests.get(url, timeout=8, headers={"Accept": "application/atom+xml"})
print(f"Status: {r.status_code}  X-Cache: {r.headers.get('X-Cache')}")

print()
print("=" * 70)
print("TEST B: Explicit descriptive User-Agent (per arXiv API guidelines)")
print("=" * 70)
r = requests.get(url, timeout=8, headers={
    "User-Agent": "ProjectParallaxBot/1.0 (mailto:reinis@example.com)"
})
print(f"Status: {r.status_code}  X-Cache: {r.headers.get('X-Cache')}")

print()
print("=" * 70)
print("TEST C: Both Accept + User-Agent combined")
print("=" * 70)
r = requests.get(url, timeout=8, headers={
    "Accept": "application/atom+xml",
    "User-Agent": "ProjectParallaxBot/1.0 (mailto:reinis@example.com)"
})
print(f"Status: {r.status_code}  X-Cache: {r.headers.get('X-Cache')}")
print(f"Body preview: {r.text[:300]}")

print()
print("=" * 70)
print("TEST D: Compare current requests default headers actually sent")
print("=" * 70)
req = requests.Request("GET", url)
prepped = requests.Session().prepare_request(req)
for k, v in prepped.headers.items():
    print(f"  {k}: {v}")
