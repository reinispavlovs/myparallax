﻿import re
from pathlib import Path

REPO_ROOT = Path(".").resolve()
utils_path = REPO_ROOT / "scripts" / "shared" / "claim_layers_utils.py"
promote_path = REPO_ROOT / "scripts" / "promote_drafts.py"

utils_src = utils_path.read_text(encoding="utf-8")
promote_src = promote_path.read_text(encoding="utf-8")

print("=" * 70)
print("[1] FULL validate_content_flags() function")
print("=" * 70)
idx = utils_src.find("def validate_content_flags")
end_idx = utils_src.find("\ndef ", idx + 10)
if end_idx == -1:
    end_idx = idx + 2500
print(utils_src[idx:end_idx])

print("=" * 70)
print("[2] promote_drafts.py - index.json entry construction")
print("=" * 70)
for kw in ["index_data", "topics[", "aggregate_risk_level", "risk_level"]:
    print(f"--- searching: {kw} ---")
    for m in re.finditer(re.escape(kw), promote_src):
        start = max(0, m.start() - 60)
        end = min(len(promote_src), m.start() + 200)
        print(f"  offset {m.start()}: ...{promote_src[start:end].replace(chr(10), ' | ')}...")
    print()
