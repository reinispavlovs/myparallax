﻿import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
src_path = REPO_ROOT / "scripts" / "promote_drafts.py"
text = src_path.read_text(encoding="utf-8")
lines = text.splitlines()

print(f"Total lines: {len(lines)}\n")

hits = []
for i, line in enumerate(lines, start=1):
    if re.search(r"cross_check|DIGEST_PATH|digest_generator", line, re.IGNORECASE):
        hits.append((i, line))

if not hits:
    print("No references to cross_check.json / DIGEST_PATH / digest_generator found.")
else:
    print(f"Found {len(hits)} reference(s):\n")
    for ln, content in hits:
        print(f"  L{ln}: {content}")

print("\n--- Score guard 'old C_i' lookup source (searching for old_c_i / previous score logic) ---")
for i, line in enumerate(lines, start=1):
    if re.search(r"old_c_i|previous.*score|old.*credibility|index\.json|topic_weights", line, re.IGNORECASE):
        print(f"  L{i}: {line}")
