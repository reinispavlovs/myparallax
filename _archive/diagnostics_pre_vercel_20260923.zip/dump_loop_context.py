﻿import re
from pathlib import Path

text = Path("digest_generator.py").read_text(encoding="utf-8")
lines = text.splitlines()

# Find the loop context
for i, line in enumerate(lines):
    if "recomputed_flags = []" in line:
        start = max(0, i-5)
        end = min(len(lines), i+15)
        print("\n".join(f"{n+1}: {l}" for n, l in enumerate(lines[start:end], start=start)))
        print("---")
