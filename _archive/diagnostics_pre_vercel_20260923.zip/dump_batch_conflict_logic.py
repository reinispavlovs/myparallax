﻿import re
from pathlib import Path

REPO_ROOT = Path(".").resolve()
digest_path = REPO_ROOT / "digest_generator.py"
src = digest_path.read_text(encoding="utf-8")
lines = src.splitlines()

print(f"[INFO] digest_generator.py total lines: {len(lines)}")
print("=" * 70)

# Find all lines mentioning batch_conflict, duplicate, topic_id grouping
keywords = ["batch_conflict", "duplicate", "conflict"]
hit_lines = []
for i, line in enumerate(lines, start=1):
    low = line.lower()
    if any(k in low for k in keywords):
        hit_lines.append(i)

print(f"[INFO] Lines mentioning conflict-related keywords: {hit_lines}")
print("=" * 70)

# Print context blocks around each hit (5 before, 15 after)
printed = set()
for hit in hit_lines:
    start = max(1, hit - 5)
    end = min(len(lines), hit + 15)
    block_key = (start, end)
    if block_key in printed:
        continue
    printed.add(block_key)
    print(f"\n--- Context around line {hit} (showing {start}-{end}) ---")
    for ln in range(start, end + 1):
        marker = ">>>" if ln == hit else "   "
        print(f"{marker} {ln:4d}: {lines[ln-1]}")

print("\n" + "=" * 70)
print("[INFO] Searching for 'promoted' field usage in same file:")
for i, line in enumerate(lines, start=1):
    if "promoted" in line.lower():
        print(f"   {i:4d}: {line}")
