﻿import json
from pathlib import Path

data = json.loads(Path("digests/cross_check.json").read_text(encoding="utf-8"))
entries = data.get("entries", [])

print("=== Full key set across all entries ===")
all_keys = set()
for e in entries:
    all_keys.update(e.keys())
print(sorted(all_keys))

print("\n=== First entry full dump ===")
print(json.dumps(entries[0], indent=2, ensure_ascii=False))
