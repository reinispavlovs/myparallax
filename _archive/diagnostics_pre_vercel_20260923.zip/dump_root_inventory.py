﻿import os
from pathlib import Path
from collections import defaultdict

root = Path(".").resolve()
groups = defaultdict(list)

for item in sorted(root.iterdir()):
    if item.name.startswith("."):
        continue
    if item.is_dir():
        groups["[DIR]"].append(item.name)
    else:
        prefix = item.name.split("_")[0].split(".")[0]
        groups[prefix].append(item.name)

for prefix, files in sorted(groups.items()):
    print(f"\n=== {prefix} ({len(files)}) ===")
    for f in files[:10]:
        print(f"  {f}")
    if len(files) > 10:
        print(f"  ... +{len(files)-10} more")
