﻿import re, shutil
from pathlib import Path
from datetime import datetime, timezone

REPO_ROOT = Path(".").resolve()
digest_path = REPO_ROOT / "digest_generator.py"
src = digest_path.read_text(encoding="utf-8")

OLD = '''        topic_seen_this_run[topic_id] = topic_seen_this_run.get(topic_id, 0) + 1
        batch_conflict = topic_seen_this_run[topic_id] > 1'''

NEW = '''        # FIX (2026-09-22): already-promoted drafts must NOT count toward
        # batch_conflict. Promoted legacy drafts (from a prior run) sharing a
        # topic_id with a brand-new pending draft is NOT a real conflict --
        # it's just publication history. Only count non-promoted drafts so a
        # single new draft per topic never self-conflicts against its own
        # already-published predecessor.
        if not meta.get("promoted"):
            topic_seen_this_run[topic_id] = topic_seen_this_run.get(topic_id, 0) + 1
        batch_conflict = topic_seen_this_run.get(topic_id, 0) > 1'''

if OLD not in src:
    print("[ABORT] Exact target block not found. No changes made.")
    print("First 50 chars of search target:", repr(OLD[:50]))
    raise SystemExit(1)

count = src.count(OLD)
print(f"[INFO] Found {count} occurrence(s) of target block.")

backup_dir = REPO_ROOT / "digests" / "_history"
backup_dir.mkdir(parents=True, exist_ok=True)
ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup_path = backup_dir / f"digest_generator.py.bak.{ts}"
shutil.copy2(digest_path, backup_path)
print(f"[OK] Backup written: {backup_path}")

new_src = src.replace(OLD, NEW)
digest_path.write_text(new_src, encoding="utf-8", newline="")
print(f"[OK] Patched: {digest_path}")

import py_compile
py_compile.compile(str(digest_path), doraise=True)
print("[OK] py_compile check passed -- digest_generator.py is syntactically valid.")
