﻿from pathlib import Path

main_path = Path("main.py")
lines = main_path.read_text(encoding="utf-8").split("\n")

print(f"main.py total lines: {len(lines)}")
print("--- process_topic() definition + first 25 lines of body ---")

start_idx = None
for i, line in enumerate(lines):
    if line.strip().startswith("def process_topic"):
        start_idx = i
        break

if start_idx is None:
    print("[ERROR] process_topic() not found")
else:
    for i in range(start_idx, min(start_idx + 30, len(lines))):
        print(f"{i+1}: {lines[i]}")

print()
print("--- Grep for print( calls containing 'topic' outside the retry block (lines < 220) ---")
for i, line in enumerate(lines):
    if i + 1 >= 220:
        break
    if "print(" in line and ("topic" in line.lower() or "tēm" in line.lower() or "sāku" in line.lower()):
        print(f"{i+1}: {line.strip()}")

print()
print("--- Grep for __main__ / main loop over TOPICS ---")
for i, line in enumerate(lines):
    if "for topic in TOPICS" in line or "if __name__" in line:
        print(f"{i+1}: {line.strip()}")
        for j in range(i, min(i + 15, len(lines))):
            print(f"    {j+1}: {lines[j]}")
        print("    ---")
