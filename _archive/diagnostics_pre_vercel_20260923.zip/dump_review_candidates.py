﻿import json
from pathlib import Path
from datetime import datetime

REPO_ROOT = Path(__file__).resolve().parent
DRAFTS_DIR = REPO_ROOT / "drafts"
CROSS_CHECK_PATH = REPO_ROOT / "digests" / "cross_check.json"

def load_cross_check():
    if not CROSS_CHECK_PATH.exists():
        return {}
    with open(CROSS_CHECK_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    entries = data.get("entries", [])
    indexed = {}
    for e in entries:
        key = e.get("draft_file") or e.get("content_file") or e.get("topic_id")
        indexed[key] = e
    return indexed

def risk_sort_key(risk):
    order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2, None: 3}
    return order.get(risk, 3)

def main():
    cross_check = load_cross_check()

    meta_files = sorted(DRAFTS_DIR.glob("*.meta.json"))
    candidates = []

    for meta_path in meta_files:
        try:
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
        except Exception as e:
            print(f"[WARN] Failed to load {meta_path.name}: {e}")
            continue

        if meta.get("promoted") is True:
            continue  # already promoted, not a candidate

        topic_id = meta.get("topic_id")
        draft_stub = meta_path.stem.replace(".meta", "")
        digest_entry = None
        for k, v in cross_check.items():
            if k and draft_stub in str(k):
                digest_entry = v
                break

        row = {
            "topic_id": topic_id,
            "draft_file": draft_stub,
            "review_status": meta.get("review_status"),
            "human_reviewed": meta.get("human_reviewed"),
            "promoted": meta.get("promoted"),
            "C_i": meta.get("credibility_score_C_i"),
            "hash_ok": digest_entry.get("content_hash_verified") if digest_entry else None,
            "topic_valid": digest_entry.get("topic_valid") if digest_entry else None,
            "risk_level": digest_entry.get("risk_level") if digest_entry else None,
            "batch_conflict": digest_entry.get("batch_conflict") if digest_entry else None,
            "auto_merge_eligible": digest_entry.get("auto_merge_eligible") if digest_entry else None,
            "generated_at": meta.get("generated_at"),
        }
        candidates.append(row)

    def blocking(row):
        return not (row["hash_ok"] is True and row["topic_valid"] is True)

    candidates.sort(key=lambda r: (
        0 if blocking(r) else 1,
        0 if r["batch_conflict"] else 1,
        risk_sort_key(r["risk_level"]),
        -(r["C_i"] if isinstance(r["C_i"], (int, float)) else -1),
    ))

    if not candidates:
        print("[OK] No pending review candidates found in drafts/ (all promoted or drafts/ empty).")
        return

    header = f"{'topic_id':<32} {'status':<10} {'C_i':>5} {'risk':<7} {'hash':<6} {'topic':<6} {'conflict':<9} {'auto_merge':<11}"
    print(header)
    print("-" * len(header))
    for r in candidates:
        print(f"{r['topic_id']:<32} {str(r['review_status']):<10} "
              f"{str(r['C_i']):>5} {str(r['risk_level']):<7} "
              f"{str(r['hash_ok']):<6} {str(r['topic_valid']):<6} "
              f"{str(r['batch_conflict']):<9} {str(r['auto_merge_eligible']):<11}")

    print(f"\nTotal candidates: {len(candidates)}")

if __name__ == "__main__":
    main()
