﻿import importlib.util
spec = importlib.util.spec_from_file_location("promote_drafts", "scripts/promote_drafts.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
print("DRAFTS_DIR =", mod.DRAFTS_DIR)
print("Exists:", mod.DRAFTS_DIR.exists())
print("Glob count:", len(list(mod.DRAFTS_DIR.glob("*.meta.json"))))
