﻿from pathlib import Path

path = Path("digest_generator.py")
src = path.read_text(encoding="utf-8")

old = 'datetime.utcnow().isoformat() + "Z"'
new = 'datetime.now(datetime.UTC).isoformat().replace("+00:00", "Z")'

if old not in src:
    print("[SKIP] Pattern not found — may already be patched or written differently.")
else:
    # Ensure datetime.UTC is available (Python 3.11+; confirmed 3.14.7 here)
    patched = src.replace(old, new)
    path.write_text(patched, encoding="utf-8", newline="")
    print("[OK] Patched datetime.utcnow() -> datetime.now(datetime.UTC)")
