﻿import re
from pathlib import Path

path = Path("digest_generator.py")
text = path.read_text(encoding="utf-8")

old = '''        recomputed_flags = []
        for layer in claim_layers:
            recomputed_flags.extend(validate_content_flags(layer))
        stored_flags = meta.get("content_flags", [])'''

new = '''        recomputed_flags_raw = []
        for layer in claim_layers:
            recomputed_flags_raw.extend(validate_content_flags(layer))
        # Order-preserving dedup: the same flagged pattern (e.g. an
        # unsourced decimal) can legitimately appear in multiple claim
        # layers (data / skeptic / synthesis) without being a distinct
        # violation. main.py stores flags deduped at generation time,
        # so recompute must match that shape or every draft false-flags
        # as "drifted" on every digest run.
        recomputed_flags = list(dict.fromkeys(recomputed_flags_raw))
        stored_flags = meta.get("content_flags", [])'''

if old not in text:
    raise SystemExit("PATCH FAILED: exact block not found — file may have shifted, aborting without writing.")

text = text.replace(old, new, 1)
path.write_text(text, encoding="utf-8", newline="")
print("Patched OK.")
