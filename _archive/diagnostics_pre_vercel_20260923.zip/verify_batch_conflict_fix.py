﻿import json
from pathlib import Path

REPO_ROOT = Path(".").resolve()
cross_check_path = REPO_ROOT / "digests" / "cross_check.json"
data = json.loads(cross_check_path.read_text(encoding="utf-8"))

print(f"[INFO] Total draft scanned: {data.get('total_draft_scanned')}")
print(f"[INFO] Flagged for review: {len(data.get('flagged_for_review', []))}")
print("=" * 70)

for entry in data.get("entries", []):
    draft_file = entry.get("draft_file", "")
    if "2026-09-22" in draft_file:
        print(f"Draft: {draft_file}")
        print(f"  topic_valid           : {entry.get('topic_valid')}")
        print(f"  content_hash_verified : {entry.get('content_hash_verified')}")
        print(f"  conflict_flag         : {entry.get('conflict_flag')}")
        print(f"  credibility_score_C_i : {entry.get('credibility_score_C_i')}")
        print(f"  current_topic_weight  : {entry.get('current_topic_weight')}")
        print(f"  auto_merge_eligible   : {entry.get('auto_merge_eligible')}")
        print("-" * 70)
