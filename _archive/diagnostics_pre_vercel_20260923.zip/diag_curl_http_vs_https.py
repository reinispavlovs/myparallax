﻿import sys
sys.path.insert(0, ".")
from main import _curl_get

url_http = "http://export.arxiv.org/api/query?search_query=all:quantum&start=0&max_results=1"
url_https = "https://export.arxiv.org/api/query?search_query=all:quantum&start=0&max_results=1"

for label, url in [("HTTP (main.py current)", url_http), ("HTTPS", url_https)]:
    r = _curl_get(url, timeout=8)
    print(f"--- {label} ---")
    print(f"status_code: {r.status_code}")
    print(f"has <entry>: {'<entry>' in r.text}")
    print(f"text length: {len(r.text)}")
    print(f"text preview: {r.text[:200]!r}")
    print()
