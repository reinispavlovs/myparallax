﻿from pathlib import Path

lines = Path("main.py").read_text(encoding="utf-8").split("\n")

print("--- Lines 240-270 (Agent 3 retry block) ---")
for i in range(239, min(270, len(lines))):
    print(f"{i+1}: {lines[i]}")
