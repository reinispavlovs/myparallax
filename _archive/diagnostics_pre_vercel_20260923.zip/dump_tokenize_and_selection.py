﻿import re
from pathlib import Path

src = Path("main.py").read_text(encoding="utf-8")
lines = src.split("\n")

# Find _tokenize function
start_idx = None
for i, line in enumerate(lines):
    if "_tokenize" in line and "def " in line:
        start_idx = i
        break

if start_idx is None:
    print("[FAIL] _tokenize function not found by name.")
else:
    print(f"=== _tokenize found at line {start_idx+1} ===")
    for i in range(max(0, start_idx-2), min(len(lines), start_idx+15)):
        print(f"{i+1}: {repr(lines[i])}")

print()
print("=== MIN_OVERLAP_RATIO occurrences ===")
for i, line in enumerate(lines):
    if "MIN_OVERLAP_RATIO" in line or "MIN_OVERLAP_COUNT" in line:
        print(f"{i+1}: {line}")

print()
print("=== Candidate selection loop (search for best_candidate / best_score / for candidate) ===")
for i, line in enumerate(lines):
    if any(kw in line for kw in ["best_candidate", "best_score", "best_ratio", "for entry", "for candidate", "entries[0]"]):
        print(f"{i+1}: {line}")
