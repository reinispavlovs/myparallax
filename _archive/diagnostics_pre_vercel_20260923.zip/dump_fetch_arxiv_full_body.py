﻿from pathlib import Path

main_py = Path("main.py")
lines = main_py.read_text(encoding="utf-8").splitlines()

print("=" * 70)
print("Full fetch_real_arxiv_summary function body (lines 132-200)")
print("=" * 70)
for i in range(131, 200):
    if i >= len(lines):
        break
    print(f"{i+1}: {lines[i]}")
