﻿from pathlib import Path

path = Path("scripts/promote_drafts.py")
text = path.read_text(encoding="utf-8")

old = '''    new_score = meta.get("credibility_score_C_i")
    if new_score is None:
        # fall back to computing risk-only comparison if score absent
        new_score = 0.0'''

new = '''    new_score = meta.get("credibility_score_C_i")
    if new_score is None:
        print(f"[REJECT] {meta_path.name}: credibility_score_C_i is missing "
              f"from metadata. Refusing to promote without a verified score "
              f"— run digest_generator.py to compute and persist it first.")
        return "rejected_missing_score"'''

if old not in text:
    raise SystemExit("Pattern not found — aborting to avoid corrupting file.")

text = text.replace(old, new)
path.write_text(text, encoding="utf-8", newline="")
print("[OK] Patched promote_drafts.py: missing score now yields "
      "explicit rejection outcome instead of silent 0.0 fallback.")
