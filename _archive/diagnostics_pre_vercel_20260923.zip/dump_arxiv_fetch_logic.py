﻿import re
from pathlib import Path

main_path = Path(".").resolve() / "main.py"
text = main_path.read_text(encoding="utf-8")
lines = text.split("\n")

# Print lines 50-80 (fetch_arxiv_summary function region)
for i in range(49, 82):
    if i < len(lines):
        print(f"L{i+1}: {lines[i]}")
