﻿from pathlib import Path
import json

articles_dir = Path("content/articles")
print("=== content/articles/ contents ===")
for f in sorted(articles_dir.glob("*.html")):
    print(" -", f.name, f.stat().st_size, "bytes")

index_path = articles_dir / "index.json"
if index_path.exists():
    idx = json.loads(index_path.read_text(encoding="utf-8"))
    print("\n=== index.json entries ===")
    print(json.dumps(idx, indent=2, ensure_ascii=False)[:2000])

log_path = Path("digests/promote_log.jsonl")
if log_path.exists():
    lines = log_path.read_text(encoding="utf-8").strip().splitlines()
    print(f"\n=== promote_log.jsonl: {len(lines)} entries ===")
    for line in lines[-4:]:
        print(line[:200])
