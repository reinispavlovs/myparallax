﻿import json
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
log_path = REPO_ROOT / "digests" / "review_log.jsonl"
meta_path = REPO_ROOT / "drafts" / "draft-consciousness_independence_nde-2026-09-20-220214.meta.json"

with open(log_path, "r", encoding="utf-8") as f:
    for line in f:
        entry = json.loads(line)
        print(json.dumps(entry, indent=2, ensure_ascii=False))

print("\n--- Cross-check against live meta.json ---")
with open(meta_path, "r", encoding="utf-8") as f:
    meta = json.load(f)
for k in ("review_status", "human_reviewed", "reviewer", "reviewed_at", "review_notes"):
    print(f"{k}: {meta.get(k)}")
