﻿import requests
import time

print("=" * 70)
print("TEST A: Minimal trivial query (different from repeated NDE query)")
print("=" * 70)
url_a = "http://export.arxiv.org/api/query?search_query=all:electron&start=0&max_results=1"
r_a = requests.get(url_a, timeout=8)
print(f"Status: {r_a.status_code}")

print()
print("=" * 70)
print("TEST B: HTTPS instead of HTTP")
print("=" * 70)
url_b = "https://export.arxiv.org/api/query?search_query=all:electron&start=0&max_results=1"
r_b = requests.get(url_b, timeout=8)
print(f"Status: {r_b.status_code}")

print()
print("=" * 70)
print("TEST C: Explicit Accept header for Atom XML")
print("=" * 70)
headers_c = {"Accept": "application/atom+xml"}
r_c = requests.get(url_a, timeout=8, headers=headers_c)
print(f"Status: {r_c.status_code}")

print()
print("=" * 70)
print("TEST D: arxiv.org base site (not export subdomain) reachability")
print("=" * 70)
try:
    r_d = requests.get("https://arxiv.org", timeout=8)
    print(f"Status: {r_d.status_code}")
except Exception as e:
    print(f"Exception: {e}")

print()
print("=" * 70)
print("TEST E: Response body/headers from a 406 for diagnostic clues")
print("=" * 70)
r_e = requests.get(url_a, timeout=8)
print(f"Status: {r_e.status_code}")
print(f"Response headers: {dict(r_e.headers)}")
print(f"Body (first 500 chars): {r_e.text[:500]}")
