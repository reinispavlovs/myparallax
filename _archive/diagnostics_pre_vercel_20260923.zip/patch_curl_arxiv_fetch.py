﻿import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

main_py = Path("main.py")
backup_dir = Path("content/articles/_history")
backup_dir.mkdir(parents=True, exist_ok=True)
ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup_path = backup_dir / f"main.py.bak.{ts}"
shutil.copy2(main_py, backup_path)
print(f"[OK] Backup created: {backup_path}")

text = main_py.read_text(encoding="utf-8")

# --- Step 1: ensure subprocess is imported ---
if "import subprocess" not in text:
    text = text.replace(
        "import requests\n",
        "import requests\nimport subprocess\n",
        1,
    )
    print("[OK] Added 'import subprocess'")
else:
    print("[SKIP] subprocess already imported")

# --- Step 2: insert _curl_get() helper right before fetch_real_arxiv_summary ---
CURL_HELPER = '''
def _curl_get(url: str, timeout: int = 8):
    """Fetches a URL via curl.exe subprocess instead of requests.get().

    Rationale (Decision #331/#333): arXiv's edge layer (Google Frontend +
    Fastly Varnish) fingerprints and blocks the TLS handshake produced by
    Python's requests/urllib3 stack, returning HTTP 406 on every
    cache-miss request \u2014 even for trivial single-word queries. curl.exe
    on Windows uses the Schannel TLS stack, which is NOT blocked, as
    confirmed by live diagnostic tests (200 OK on identical cache-miss
    requests). This wrapper mimics the minimal requests.Response
    interface (.status_code, .text) so downstream parsing logic in
    fetch_real_arxiv_summary() requires zero changes.
    """
    class _CurlResponse:
        def __init__(self, status_code: int, text: str):
            self.status_code = status_code
            self.text = text

    proc = subprocess.run(
        ["curl.exe", "-s", "-w", "\\n%{http_code}", url],
        capture_output=True,
        timeout=timeout,
    )
    raw = proc.stdout.decode("utf-8", errors="replace")
    parts = raw.rsplit("\\n", 1)
    if len(parts) == 2:
        body, status_str = parts
    else:
        body, status_str = raw, ""
    try:
        status_code = int(status_str.strip())
    except ValueError:
        status_code = 0
    return _CurlResponse(status_code, body)


'''

marker = "def fetch_real_arxiv_summary(query: str) -> dict:"
if "_curl_get" not in text:
    idx = text.index(marker)
    text = text[:idx] + CURL_HELPER.lstrip("\n") + "\n" + text[idx:]
    print("[OK] Inserted _curl_get() helper")
else:
    print("[SKIP] _curl_get() already present")

# --- Step 3: replace requests.get call inside fetch_real_arxiv_summary ---
old_call = "        r = requests.get(url, timeout=8)"
new_call = "        r = _curl_get(url, timeout=8)"
if old_call in text:
    text = text.replace(old_call, new_call, 1)
    print("[OK] Replaced requests.get() with _curl_get() in fetch_real_arxiv_summary")
elif new_call in text:
    print("[SKIP] Already using _curl_get()")
else:
    print("[WARN] Could not locate requests.get(url, timeout=8) line \u2014 no changes made to call site")
    sys.exit(1)

main_py.write_text(text, encoding="utf-8")
print("[OK] main.py written")

# --- Step 4: syntax check ---
result = subprocess.run([sys.executable, "-m", "py_compile", str(main_py)], capture_output=True, text=True)
if result.returncode == 0:
    print("[OK] py_compile passed \u2014 main.py is syntactically valid")
else:
    print("[FAIL] py_compile errors:")
    print(result.stdout)
    print(result.stderr)
    sys.exit(1)
