﻿import sys
import re
from pathlib import Path
from urllib.parse import quote
import requests

sys.path.insert(0, str(Path(".").resolve()))

STOPWORDS = {"a", "an", "the", "of", "in", "on", "and", "or", "to",
             "for", "with", "at", "by"}

def _tokenize(s):
    s = s.lower()
    s = s.replace("out-of-body", " outofbodyanchor ")
    s = s.replace("out of body", " outofbodyanchor ")
    s = s.replace("near-death", " neardeathanchor ")
    s = s.replace("near death", " neardeathanchor ")
    s = re.sub(r"[^a-z0-9\s-]", " ", s)
    s = s.replace("-", " ")
    return {t for t in s.split() if t and t not in STOPWORDS}

query = "quantum brain biology consciousness out-of-body experience clinical"
query_tokens = _tokenize(query)
print(f"Query tokens: {sorted(query_tokens)}\n")

encoded_query = quote(query)
url = f"http://export.arxiv.org/api/query?search_query=all:{encoded_query}&start=0&max_results=5"
r = requests.get(url, timeout=8)
entries = r.text.split("<entry>")[1:]

for i, entry_block in enumerate(entries):
    title = ""
    summary = ""
    if "<title>" in entry_block:
        title = entry_block.split("<title>")[1].split("</title>")[0]
    if "<summary>" in entry_block:
        summary = entry_block.split("<summary>")[1].split("</summary>")[0]
    combined = re.sub(r"\s+", " ", f"{title} {summary}").strip()
    candidate_tokens = _tokenize(combined)
    overlap = query_tokens & candidate_tokens
    ratio = len(overlap) / len(query_tokens) if query_tokens else 0.0
    print(f"--- Candidate {i+1} ---")
    print(f"Title: {title.strip()}")
    print(f"Matched tokens: {sorted(overlap)}")
    print(f"Overlap: {len(overlap)}/{len(query_tokens)} = {round(ratio,2)}")
    print()
