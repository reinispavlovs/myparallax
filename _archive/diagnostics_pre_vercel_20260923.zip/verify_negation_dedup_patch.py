﻿from pathlib import Path

root = Path(".").resolve()

print("=" * 70)
print("main.py -- lines 410-440 (post-patch)")
print("=" * 70)
mlines = (root / "main.py").read_text(encoding="utf-8").splitlines()
for i in range(409, min(440, len(mlines))):
    print(f"{i+1:4d}: {mlines[i]}")

print()
print("=" * 70)
print("claim_layers_utils.py -- lines 1-40 (post-patch, constants block)")
print("=" * 70)
ulines = (root / "scripts" / "shared" / "claim_layers_utils.py").read_text(encoding="utf-8").splitlines()
for i in range(0, min(40, len(ulines))):
    print(f"{i+1:4d}: {ulines[i]}")

print()
print("=" * 70)
print("claim_layers_utils.py -- validate_content_flags() full body (post-patch)")
print("=" * 70)
start = None
for i, line in enumerate(ulines):
    if line.strip().startswith("def validate_content_flags"):
        start = i
        break
if start is not None:
    end = start + 1
    while end < len(ulines) and not (ulines[end].startswith("def ") and end > start + 1):
        end += 1
        if end - start > 40:
            break
    for j in range(start, min(end, len(ulines))):
        print(f"{j+1:4d}: {ulines[j]}")
else:
    print("[FAIL] function not found")
