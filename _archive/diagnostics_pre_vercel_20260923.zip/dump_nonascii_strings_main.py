﻿import re
from pathlib import Path

main_path = Path(".").resolve() / "main.py"
text = main_path.read_text(encoding="utf-8")
lines = text.split("\n")

print(f"Scanning {main_path} ({len(lines)} lines)\n")
print("="*70)

found = []
for i, line in enumerate(lines, start=1):
    non_ascii_chars = [c for c in line if ord(c) > 127]
    if non_ascii_chars:
        found.append((i, line))

print(f"Total lines with non-ASCII characters: {len(found)}\n")
for lineno, line in found:
    print(f"L{lineno}: {line.strip()[:120]}")

print("="*70)
print("Done.")
