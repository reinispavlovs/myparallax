﻿from pathlib import Path

src = Path("digest_generator.py").read_text(encoding="utf-8")
lines = src.splitlines()

print("=== IMPORT BLOCK (first 20 lines) ===")
for i, line in enumerate(lines[:20], 1):
    print(f"{i:3}: {line}")

print("\n=== canonical_topics ASSIGNMENT ===")
for i, line in enumerate(lines, 1):
    if "canonical_topics" in line:
        print(f"{i:3}: {line}")
