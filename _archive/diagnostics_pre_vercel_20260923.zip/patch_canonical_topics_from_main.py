﻿from pathlib import Path
import re
import shutil
from datetime import datetime, UTC

target = Path("digest_generator.py")
src = target.read_text(encoding="utf-8")

if "from main import TOPICS" in src:
    print("[SKIP] Already patched.")
else:
    backup_dir = Path("digests/_history")
    backup_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    backup_path = backup_dir / f"digest_generator.py.bak.{ts}"
    shutil.copy2(target, backup_path)
    print(f"[BACKUP] {backup_path}")

    new_src = src
    patched_import = False
    patched_assignment = False

    import_match = re.search(r"^(import .+\n|from .+\n)", new_src, re.MULTILINE)
    if import_match:
        insert_pos = import_match.end()
        new_src = (
            new_src[:insert_pos]
            + "\nimport sys\nfrom pathlib import Path as _PatchPath\n"
            + "_REPO_ROOT_FOR_IMPORT = _PatchPath(__file__).resolve().parent\n"
            + "if str(_REPO_ROOT_FOR_IMPORT) not in sys.path:\n"
            + "    sys.path.insert(0, str(_REPO_ROOT_FOR_IMPORT))\n"
            + "from main import TOPICS as _CANONICAL_TOPICS_SOURCE\n\n"
            + new_src[insert_pos:]
        )
        patched_import = True

    pattern = re.compile(
        r"canonical_topics\s*=\s*set\(\s*index_data\.get\(\s*[\"']topic_keys_reference[\"']\s*,\s*\[\]\s*\)\s*\)"
    )
    if pattern.search(new_src):
        new_src = pattern.sub(
            'canonical_topics = {t["id"] for t in _CANONICAL_TOPICS_SOURCE}',
            new_src,
        )
        patched_assignment = True
    else:
        print("[WARN] canonical_topics assignment pattern not found -- manual check needed.")

    target.write_text(new_src, encoding="utf-8", newline="")
    print(f"[PATCH] import inserted: {patched_import}")
    print(f"[PATCH] assignment replaced: {patched_assignment}")
