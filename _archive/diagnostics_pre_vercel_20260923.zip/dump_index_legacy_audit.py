﻿import json
from pathlib import Path

REPO_ROOT = Path(".").resolve()
INDEX_PATH = REPO_ROOT / "content" / "articles" / "index.json"

with open(INDEX_PATH, "r", encoding="utf-8") as f:
    index_data = json.load(f)

print("Top-level keys:", list(index_data.keys()))

topics = index_data.get("topics", {})
print(f"Total topic buckets: {len(topics)}")

total_articles = 0
missing_ci = []
has_ci = []

for topic_id, articles in topics.items():
    if not isinstance(articles, list):
        print(f"  [WARN] topics['{topic_id}'] is not a list: {type(articles)}")
        continue
    for art in articles:
        total_articles += 1
        ci = art.get("credibility_score_C_i", None)
        entry_info = {
            "topic_id": topic_id,
            "content_file": art.get("content_file"),
            "promoted_at": art.get("promoted_at"),
            "generated_at": art.get("generated_at"),
            "credibility_score_C_i": ci,
        }
        if ci is None:
            missing_ci.append(entry_info)
        else:
            has_ci.append(entry_info)

print(f"\nTotal articles in index.json: {total_articles}")
print(f"Articles WITH credibility_score_C_i: {len(has_ci)}")
print(f"Articles MISSING credibility_score_C_i: {len(missing_ci)}")

print("\n--- Articles WITH C_i ---")
for a in has_ci:
    print(a)

print("\n--- Articles MISSING C_i (legacy candidates) ---")
for a in missing_ci:
    print(a)
