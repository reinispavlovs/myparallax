﻿import requests
import time

print("=" * 70)
print("TEST 1: Force cache-miss on 'electron' via unique param")
print("=" * 70)
url1 = "https://export.arxiv.org/api/query?search_query=all:electron&start=0&max_results=1&_cb=99999"
r1 = requests.get(url1, timeout=8)
print(f"Status: {r1.status_code}")
print(f"X-Cache: {r1.headers.get('X-Cache', 'N/A')}")

print()
print("=" * 70)
print("TEST 2: Retry ORIGINAL electron query immediately (check cache stability)")
print("=" * 70)
url2 = "https://export.arxiv.org/api/query?search_query=all:electron&start=0&max_results=1"
r2 = requests.get(url2, timeout=8)
print(f"Status: {r2.status_code}")
print(f"X-Cache: {r2.headers.get('X-Cache', 'N/A')}")

print()
print("=" * 70)
print("TEST 3: Check arxiv.org official API status / announcement page")
print("=" * 70)
try:
    r3 = requests.get("https://info.arxiv.org/help/api/index.html", timeout=8)
    print(f"Status: {r3.status_code}")
    if "deprecat" in r3.text.lower():
        print("WARNING: page mentions deprecation")
    if "406" in r3.text:
        print("WARNING: page mentions 406")
except Exception as e:
    print(f"Exception: {e}")

print()
print("=" * 70)
print("TEST 4: Try the newer arxiv.org/abs listing API (non-export subdomain)")
print("=" * 70)
try:
    url4 = "https://arxiv.org/a/find/all?searchtype=all&query=electron"
    r4 = requests.get(url4, timeout=8)
    print(f"Status: {r4.status_code}")
except Exception as e:
    print(f"Exception: {e}")
