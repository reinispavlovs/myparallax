﻿from pathlib import Path

target = Path(".").resolve() / "scripts" / "promote_drafts.py"
lines = target.read_text(encoding="utf-8").splitlines()

anchor = "PROMOTED_ARCHIVE_DIR.mkdir"
found = False
for i, line in enumerate(lines):
    if anchor in line:
        found = True
        start = max(0, i - 15)
        end = min(len(lines), i + 20)
        print(f"--- context around line {i+1} ---")
        for j in range(start, end):
            print(f"{j+1:4d}: {lines[j]}")
        break

if not found:
    print("[FAIL] anchor not found")
