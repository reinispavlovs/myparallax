﻿import json
from pathlib import Path

p = Path("digests/cross_check.json")
print(f"File size: {p.stat().st_size} bytes")
print(f"Last modified: {p.stat().st_mtime}")

data = json.loads(p.read_text(encoding="utf-8"))

print(f"\nTop-level type: {type(data)}")
if isinstance(data, dict):
    print(f"Top-level keys: {list(data.keys())}")
    for k, v in data.items():
        if isinstance(v, list):
            print(f"  key='{k}' -> list of length {len(v)}")
        else:
            print(f"  key='{k}' -> {type(v)}")
elif isinstance(data, list):
    print(f"Top-level list length: {len(data)}")
