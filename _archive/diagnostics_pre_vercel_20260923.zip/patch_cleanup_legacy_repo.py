﻿import shutil
from pathlib import Path
from datetime import datetime, timezone

legacy = Path("myparallax_repo")
archive_dir = Path("_archive")
archive_dir.mkdir(exist_ok=True)

timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
archive_path = archive_dir / f"myparallax_repo_legacy_{timestamp}"

if not legacy.exists():
    print("myparallax_repo/ already gone. Nothing to do.")
else:
    print(f"Archiving {legacy.resolve()} -> {archive_path}.zip")
    shutil.make_archive(str(archive_path), "zip", root_dir=str(legacy))

    zip_file = Path(f"{archive_path}.zip")
    if zip_file.exists() and zip_file.stat().st_size > 0:
        print(f"Archive created: {zip_file} ({zip_file.stat().st_size} bytes)")
        shutil.rmtree(legacy)
        print(f"Deleted {legacy}/ — cleanup complete.")
    else:
        print("ERROR: archive failed or is empty. Aborting deletion for safety.")
