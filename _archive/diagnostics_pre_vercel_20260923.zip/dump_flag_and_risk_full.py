﻿import re
from pathlib import Path

REPO_ROOT = Path(".").resolve()
utils_path = REPO_ROOT / "scripts" / "shared" / "claim_layers_utils.py"
main_path = REPO_ROOT / "main.py"

utils_src = utils_path.read_text(encoding="utf-8")
main_src = main_path.read_text(encoding="utf-8")

print("=" * 70)
print("[1] FULL validate_content_flags()")
print("=" * 70)
idx = utils_src.find("def validate_content_flags")
end_idx = utils_src.find("\ndef ", idx + 10)
print(utils_src[idx:end_idx])

print("=" * 70)
print("[2] FULL aggregate_risk_level()")
print("=" * 70)
idx2 = utils_src.find("def aggregate_risk_level")
end_idx2 = utils_src.find("\ndef ", idx2 + 10)
print(utils_src[idx2:end_idx2])

print("=" * 70)
print("[3] Does meta.json have top-level risk_level key at write-time in main.py?")
print("=" * 70)
nl = chr(10)
sep = " | "
for m in re.finditer(r'"risk_level"', main_src):
    start = max(0, m.start() - 100)
    end = min(len(main_src), m.start() + 100)
    snippet = main_src[start:end].replace(nl, sep)
    print(f"offset {m.start()}: ...{snippet}...")
    print()
