﻿import json
from pathlib import Path

REPO_ROOT = Path(".").resolve()
WEIGHTS_PATH = REPO_ROOT / "content" / "articles" / "topic_weights.json"

data = json.loads(WEIGHTS_PATH.read_text(encoding="utf-8"))

print(f"=== Top-level keys: {list(data.keys())} ===\n")

for k, v in data.items():
    if isinstance(v, dict):
        print(f"{k!r}: dict with keys {list(v.keys())[:5]}{'...' if len(v.keys())>5 else ''}")
    else:
        print(f"{k!r}: {v!r} (type={type(v).__name__})")

print("\n=== Full JSON ===")
print(json.dumps(data, indent=2, ensure_ascii=False))
