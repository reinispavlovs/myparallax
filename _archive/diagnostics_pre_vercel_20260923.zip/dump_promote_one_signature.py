﻿from pathlib import Path

target = Path(".").resolve() / "scripts" / "promote_drafts.py"
lines = target.read_text(encoding="utf-8").splitlines()

anchor = "def promote_one"
found = False
for i, line in enumerate(lines):
    if anchor in line:
        found = True
        start = i
        end = min(len(lines), i + 40)
        print(f"--- promote_one() from line {i+1} ---")
        for j in range(start, end):
            print(f"{j+1:4d}: {lines[j]}")
        break

if not found:
    print("[FAIL] anchor not found")
