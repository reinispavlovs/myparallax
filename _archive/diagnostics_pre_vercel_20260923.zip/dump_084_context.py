﻿import json
import re
from pathlib import Path

drafts_dir = Path("drafts")
meta_path = drafts_dir / "draft-consciousness_independence_nde-2026-09-20-220214.meta.json"
html_path = drafts_dir / "draft-consciousness_independence_nde-2026-09-20-220214.html"

meta = json.loads(meta_path.read_text(encoding="utf-8"))
html = html_path.read_text(encoding="utf-8")

print("=== meta.json content_flags (stored) ===")
print(meta.get("content_flags"))

print("\n=== claim_layers (raw) ===")
print(json.dumps(meta.get("claim_layers"), indent=2, ensure_ascii=False))

print("\n=== Context around '0.84' in HTML ===")
for m in re.finditer(r"0\.84", html):
    start = max(0, m.start() - 200)
    end = min(len(html), m.end() + 200)
    print("---")
    print(html[start:end])

print("\n=== Context around '0.84' in meta.json raw text ===")
meta_raw = meta_path.read_text(encoding="utf-8")
for m in re.finditer(r"0\.84", meta_raw):
    start = max(0, m.start() - 200)
    end = min(len(meta_raw), m.end() + 200)
    print("---")
    print(meta_raw[start:end])
