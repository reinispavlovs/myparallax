﻿import json
from pathlib import Path

path = Path("content/articles/index.json")
data = json.loads(path.read_text(encoding="utf-8"))

print("Top-level keys:", list(data.keys()))
print()
print("topic_keys_reference present:", "topic_keys_reference" in data)
print("topic_keys_reference value:", data.get("topic_keys_reference"))
print()
print("topics keys (from earlier verify_promotion_result.py output):")
if "topics" in data:
    print(list(data["topics"].keys()))
