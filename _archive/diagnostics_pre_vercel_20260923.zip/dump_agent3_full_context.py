﻿from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
main_path = REPO_ROOT / "main.py"

with open(main_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

print(f"Total lines: {len(lines)}\n")

print("=== Lines 90-200 (Agent 1 data dict + model_note usage) ===")
for i in range(89, 200):
    if i < len(lines):
        print(f"{i+1:4}: {lines[i]}", end="")

print("\n\n=== Searching for prompt/messages construction (Agent 3 API call) ===")
for i, line in enumerate(lines, start=1):
    if any(kw in line for kw in ["messages", "\"role\"", "'role'", "system", "prompt", "content=f", "requests.post", "client.chat", "chat.completions"]):
        print(f"L{i:4}: {line.rstrip()}")
