﻿from pathlib import Path

path = Path("main.py")
lines = path.read_text(encoding="utf-8").splitlines()

print("=== Selection loop context (searching for best_ratio / best_candidate) ===")
for i, line in enumerate(lines, start=1):
    low = line.lower()
    if "best_ratio" in low or "best_candidate" in low or "best_overlap" in low or ("ratio" in low and (">" in line or ">=" in line)):
        print(f"{i}: {line}")
