﻿import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
PROMOTE_PATH = REPO_ROOT / "scripts" / "promote_drafts.py"

text = PROMOTE_PATH.read_text(encoding="utf-8")
lines = text.splitlines()

print("=== def bump_weight() full body ===")
start = None
for i, l in enumerate(lines):
    if l.strip().startswith("def bump_weight"):
        start = i
        break
if start is not None:
    depth_end = start + 1
    for j in range(start+1, len(lines)):
        if lines[j].strip().startswith("def ") and not lines[j].startswith(" "):
            break
        depth_end = j
    for k in range(start, depth_end+1):
        print(f"{k+1:4}: {lines[k]}")
else:
    print("bump_weight() definition not found!")

print("\n=== All references to current_weight / weight_history / topic_weights across repo ===")
targets = ["current_weight", "weight_history", "topic_weights.json"]
for py_file in REPO_ROOT.rglob("*.py"):
    if "_archive" in str(py_file) or "_history" in str(py_file):
        continue
    try:
        content = py_file.read_text(encoding="utf-8")
    except Exception:
        continue
    for tgt in targets:
        for m in re.finditer(re.escape(tgt), content):
            line_no = content[:m.start()].count("\n") + 1
            line_text = content.splitlines()[line_no-1].strip()
            print(f"{py_file.relative_to(REPO_ROOT)}:{line_no}: {line_text}")
