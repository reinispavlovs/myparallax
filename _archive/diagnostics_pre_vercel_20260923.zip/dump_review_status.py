﻿import json
from pathlib import Path

drafts_dir = Path("drafts")
for meta_file in sorted(drafts_dir.glob("*.meta.json")):
    with open(meta_file, "r", encoding="utf-8") as f:
        meta = json.load(f)
    topic = str(meta.get("topic_id"))
    status = str(meta.get("review_status"))
    reviewed = str(meta.get("human_reviewed"))
    promoted = str(meta.get("promoted"))
    print(f"{topic:40} review_status={status:10} human_reviewed={reviewed:5} promoted={promoted:5}")
