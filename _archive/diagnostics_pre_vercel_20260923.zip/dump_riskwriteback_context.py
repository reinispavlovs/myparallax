﻿import re
from pathlib import Path

REPO_ROOT = Path(".").resolve()
digest_path = REPO_ROOT / "digest_generator.py"
digest_src = digest_path.read_text(encoding="utf-8")

print("=" * 70)
print("[1] FULL aggregate_risk_level() in digest_generator.py")
print("=" * 70)
idx = digest_src.find("def aggregate_risk_level")
end_idx = digest_src.find("\ndef ", idx + 10)
print(digest_src[idx:end_idx])

print("=" * 70)
print("[2] Writeback block for credibility_score_C_i (context)")
print("=" * 70)
idx2 = digest_src.find("credibility_score_C_i")
# find the writeback section - look for meta[ or save_meta near this
nl = chr(10)
for m in re.finditer(r"credibility_score_C_i", digest_src):
    pass
# print a big window around the first writeback occurrence
writeback_idx = digest_src.find("credibility_scored_at")
start = max(0, writeback_idx - 600)
end = min(len(digest_src), writeback_idx + 600)
print(digest_src[start:end])
