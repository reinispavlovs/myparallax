﻿from pathlib import Path
import re

path = Path("digest_generator.py")
src = path.read_text(encoding="utf-8")

# Find canonical_topics definition and usage
lines = src.splitlines()
for i, line in enumerate(lines):
    if "canonical_topics" in line or "topic_valid" in line:
        start = max(0, i - 2)
        end = min(len(lines), i + 3)
        print(f"--- lines {start+1}-{end} ---")
        for j in range(start, end):
            print(f"{j+1}: {lines[j]}")
        print()
