﻿import re
import py_compile
from pathlib import Path
from datetime import datetime, timezone

path = Path("main.py")
src = path.read_text(encoding="utf-8")

old_block = '''    def _tokenize(s: str) -> set:
        s = s.lower()
        s = re.sub(r"[^a-z0-9\\s-]", " ", s)
        s = s.replace("-", " ")
        return {t for t in s.split() if t and t not in STOPWORDS}'''

new_block = '''    def _tokenize(s: str) -> set:
        s = s.lower()
        s = s.replace("out-of-body", " outofbodyanchor ")
        s = s.replace("out of body", " outofbodyanchor ")
        s = s.replace("near-death", " neardeathanchor ")
        s = s.replace("near death", " neardeathanchor ")
        s = re.sub(r"[^a-z0-9\\s-]", " ", s)
        s = s.replace("-", " ")
        return {t for t in s.split() if t and t not in STOPWORDS}'''

if old_block not in src:
    raise SystemExit("[FAIL] Exact _tokenize block not found. Aborting, no changes made.")

count = src.count(old_block)
if count != 1:
    raise SystemExit(f"[FAIL] Expected exactly 1 occurrence, found {count}. Aborting.")

src = src.replace(old_block, new_block, 1)

backup_dir = Path("_history")
backup_dir.mkdir(exist_ok=True)
ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup_path = backup_dir / f"main.py.bak.{ts}"
backup_path.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
print(f"[BACKUP] {backup_path}")

path.write_text(src, encoding="utf-8")
print("[OK] Patched _tokenize with phrase-anchor consumption (out-of-body, near-death).")

py_compile.compile("main.py", doraise=True)
print("[OK] main.py compiles successfully.")
