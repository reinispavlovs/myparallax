﻿from pathlib import Path

root = Path(".").resolve()

# 1. claim_layers_utils.py - validate_content_flags() full source
utils_path = root / "scripts" / "shared" / "claim_layers_utils.py"
lines = utils_path.read_text(encoding="utf-8").splitlines()

print("=" * 70)
print("FILE: scripts/shared/claim_layers_utils.py")
print("=" * 70)

anchor_found = False
for i, line in enumerate(lines):
    if "PRECISE_DECIMAL_PATTERN" in line and "=" in line and "def" not in line:
        print(f"{i+1:4d}: {line}")
    if line.strip().startswith("def validate_content_flags"):
        anchor_found = True
        start = i
        # print until next top-level def or 60 lines, whichever first
        end = start + 1
        while end < len(lines) and not (lines[end].startswith("def ") and end > start + 1):
            end += 1
            if end - start > 60:
                break
        print(f"--- validate_content_flags() from line {start+1} to {end} ---")
        for j in range(start, min(end, len(lines))):
            print(f"{j+1:4d}: {lines[j]}")

if not anchor_found:
    print("[FAIL] validate_content_flags not found")

# 2. main.py - content_flags construction / extend calls
main_path = root / "main.py"
mlines = main_path.read_text(encoding="utf-8").splitlines()

print("=" * 70)
print("FILE: main.py -- content_flags construction")
print("=" * 70)

for i, line in enumerate(mlines):
    if "content_flags" in line:
        print(f"{i+1:4d}: {line}")
