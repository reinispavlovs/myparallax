﻿from pathlib import Path

REPO_ROOT = Path(".").resolve()
target = REPO_ROOT / "scripts" / "promote_drafts.py"
lines = target.read_text(encoding="utf-8").splitlines()

print(f"Total lines: {len(lines)}")
print()
print("--- Lines 170-260 (promote_one body) ---")
for i in range(169, min(260, len(lines))):
    print(f"{i+1}: {lines[i]}")
