﻿import re
from pathlib import Path

text = Path("digest_generator.py").read_text(encoding="utf-8")
lines = text.splitlines()

for i, line in enumerate(lines):
    if "def normalize_claim_layers" in line:
        # print until next top-level def
        end = i + 1
        while end < len(lines) and not (lines[end].startswith("def ") or lines[end].startswith("class ")):
            end += 1
        print("\n".join(f"{n+1}: {l}" for n, l in enumerate(lines[i:end], start=i)))
