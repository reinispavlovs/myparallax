from dotenv import load_dotenv
import os

load_dotenv(override=True)
key = os.getenv("XAI_API_KEY")

if key is None:
    print("XAI_API_KEY not found in environment.")
else:
    print("Length:", len(key))
    print("Count of 'xai-' substrings:", key.count("xai-"))
    print("Repr:", repr(key))
