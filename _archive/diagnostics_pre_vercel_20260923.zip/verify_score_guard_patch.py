﻿from pathlib import Path

path = Path("scripts/promote_drafts.py")
lines = path.read_text(encoding="utf-8").splitlines()

start, end = 178, 198
print(f"--- promote_drafts.py lines {start}-{end} ---")
for i in range(start-1, end):
    print(f"{i+1}: {lines[i]}")
