﻿import json
from pathlib import Path

meta_path = Path("drafts/draft-consciousness_independence_nde-2026-09-22-113022.meta.json")
html_path = Path("drafts/draft-consciousness_independence_nde-2026-09-22-113022.html")

meta = json.loads(meta_path.read_text(encoding="utf-8"))
html = html_path.read_text(encoding="utf-8")

print("=== content_flags ===")
print(meta.get("content_flags"))

print("\n=== HTML context around '0.84' ===")
idx = html.find("0.84")
if idx == -1:
    print("NOT FOUND in HTML (likely in meta-only fields)")
else:
    print(html[max(0,idx-200):idx+200])

print("\n=== meta model_note ===")
print(meta.get("model_note", "")[:300])
print("\n=== meta skeptic_critique ===")
print(meta.get("skeptic_critique", "")[:300])
