﻿import pathlib
p = pathlib.Path("scripts/review_cli.py").resolve()
lines = p.read_text(encoding="utf-8").splitlines()
for i, line in enumerate(lines, 1):
    print(f"{i:4}: {line}")
