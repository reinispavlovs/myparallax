﻿from pathlib import Path

target = Path(".").resolve() / "scripts" / "promote_drafts.py"
lines = target.read_text(encoding="utf-8").splitlines()

for i, line in enumerate(lines[:30]):
    print(f"{i+1:4d}: {line}")
