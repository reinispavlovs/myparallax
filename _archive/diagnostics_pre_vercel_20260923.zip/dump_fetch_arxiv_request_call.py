﻿import re
from pathlib import Path

main_py = Path("main.py")
text = main_py.read_text(encoding="utf-8")
lines = text.splitlines()

print("=" * 70)
print("Locating requests.get() calls and arXiv fetch function")
print("=" * 70)

for i, line in enumerate(lines, start=1):
    if "requests.get" in line or "def fetch_real_arxiv_summary" in line or "import requests" in line:
        start = max(0, i - 3)
        end = min(len(lines), i + 15)
        print(f"\n--- Context around line {i} ---")
        for j in range(start, end):
            marker = ">>>" if j == i - 1 else "   "
            print(f"{marker} {j+1}: {lines[j]}")
