﻿from pathlib import Path
import json

drafts_dir = Path("drafts")
meta_files = sorted(drafts_dir.glob("*.meta.json"))

print(f"Total .meta.json files: {len(meta_files)}\n")

by_topic = {}
for mf in meta_files:
    meta = json.loads(mf.read_text(encoding="utf-8"))
    topic = meta.get("topic_id", "UNKNOWN")
    by_topic.setdefault(topic, []).append((mf.name, meta.get("generated_at"), meta.get("promoted")))

for topic, entries in by_topic.items():
    print(f"=== {topic} ({len(entries)} drafts) ===")
    for name, gen_at, promoted in sorted(entries):
        print(f"  {name} | generated_at={gen_at} | promoted={promoted}")
    print()
