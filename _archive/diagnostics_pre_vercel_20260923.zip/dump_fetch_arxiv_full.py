﻿from pathlib import Path

root = Path(".").resolve()
lines = (root / "main.py").read_text(encoding="utf-8").splitlines()

print(f"Total lines in main.py: {len(lines)}")
print("=" * 70)

# Find fetch_real_arxiv_summary boundaries
start = None
for i, line in enumerate(lines):
    if line.strip().startswith("def fetch_real_arxiv_summary"):
        start = i
        break

if start is None:
    print("[FAIL] fetch_real_arxiv_summary not found")
else:
    # find end: next top-level "def " at column 0
    end = start + 1
    while end < len(lines):
        if lines[end].startswith("def ") and end > start + 1:
            break
        end += 1
    print(f"fetch_real_arxiv_summary spans lines {start+1} to {end} ({end-start} lines)")
    print("=" * 70)
    for i in range(start, end):
        print(f"{i+1:4d}: {lines[i]}")
