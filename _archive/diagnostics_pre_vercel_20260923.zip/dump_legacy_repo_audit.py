﻿import json
from pathlib import Path

legacy = Path("myparallax_repo")

if not legacy.exists():
    print("myparallax_repo/ does not exist. Nothing to clean up.")
else:
    print(f"=== myparallax_repo/ exists at: {legacy.resolve()} ===\n")

    all_files = list(legacy.rglob("*"))
    print(f"Total items (files+dirs): {len(all_files)}\n")

    print("=== Top-level contents ===")
    for item in sorted(legacy.iterdir()):
        kind = "DIR " if item.is_dir() else "FILE"
        print(f"{kind} {item.name}")

    print("\n=== Any .html or .meta.json drafts inside? ===")
    html_files = list(legacy.rglob("*.html"))
    meta_files = list(legacy.rglob("*.meta.json"))
    print(f"HTML files: {len(html_files)}")
    for f in html_files:
        print(f"  {f}")
    print(f"meta.json files: {len(meta_files)}")
    for f in meta_files:
        print(f"  {f}")

    print("\n=== Any .py files with logic not present in root? ===")
    py_files = list(legacy.rglob("*.py"))
    for f in py_files:
        print(f"  {f}  ({f.stat().st_size} bytes)")

    print("\n=== Total size ===")
    total_size = sum(f.stat().st_size for f in all_files if f.is_file())
    print(f"{total_size} bytes ({total_size/1024:.1f} KB)")
