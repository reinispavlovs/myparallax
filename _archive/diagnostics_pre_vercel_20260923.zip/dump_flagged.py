﻿import json
from pathlib import Path

data = json.loads(Path("digests/cross_check.json").read_text(encoding="utf-8"))

# Try to locate the flagged_for_review list regardless of top-level key name
flagged = data.get("flagged_for_review") or data.get("flagged") or []
print(f"Total flagged: {len(flagged)}")
print("=" * 70)
for item in flagged:
    print(f"Draft: {item.get('draft')}")
    print(f"Reason: {item.get('reason')}")
    print("-" * 70)
