﻿import requests
from urllib.parse import quote

query = "quantum brain biology consciousness out-of-body experience clinical"
encoded_query = quote(query)
url = f"http://export.arxiv.org/api/query?search_query=all:{encoded_query}&start=0&max_results=5"

print("=" * 70)
print("TEST 1: No headers (current main.py behavior)")
print("=" * 70)
r1 = requests.get(url, timeout=8)
print(f"Status: {r1.status_code}")

print()
print("=" * 70)
print("TEST 2: With User-Agent header")
print("=" * 70)
headers = {"User-Agent": "ProjectParallax-ResearchBot/1.0 (mailto:research@example.com)"}
r2 = requests.get(url, timeout=8, headers=headers)
print(f"Status: {r2.status_code}")
print(f"Has <entry>: {'<entry>' in r2.text}")

print()
print("=" * 70)
print("TEST 3: Retry without headers (check if transient)")
print("=" * 70)
import time
time.sleep(2)
r3 = requests.get(url, timeout=8)
print(f"Status: {r3.status_code}")
