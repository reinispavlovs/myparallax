﻿import sys
from pathlib import Path

root = Path(".").resolve()
sys.path.insert(0, str(root))

import main as m

print("=" * 70)
print("STRUCTURAL CHECK")
print("=" * 70)
required = ["tokenize_arxiv_text", "score_arxiv_candidate",
            "select_best_arxiv_candidate", "fetch_real_arxiv_summary",
            "PHRASE_ANCHORS", "MIN_ARXIV_OVERLAP_COUNT", "MIN_ARXIV_OVERLAP_RATIO"]
for name in required:
    ok = hasattr(m, name)
    print(f"  {'[OK]' if ok else '[FAIL]'} main.{name} {'exists' if ok else 'MISSING'}")

print()
print("=" * 70)
print("FUNCTIONAL CHECK: tokenize_arxiv_text phrase anchors")
print("=" * 70)
t1 = m.tokenize_arxiv_text("out-of-body experience study")
t2 = m.tokenize_arxiv_text("many-body problem in physics")
print(f"  'out-of-body experience study' -> {t1}")
print(f"  'many-body problem in physics' -> {t2}")
collision = "outofbodyanchor" in t2
print(f"  False collision risk (anchor leaking into 'many-body')? {collision}")

print()
print("=" * 70)
print("FUNCTIONAL CHECK: live NDE candidate selection (network call)")
print("=" * 70)
query = "quantum brain biology consciousness out-of-body experience clinical"
result = m.fetch_real_arxiv_summary(query)
print(f"  found: {result.get('found')}")
print(f"  overlap_count: {result.get('relevance_overlap_count')}")
print(f"  overlap_ratio: {result.get('relevance_overlap_ratio')}")
print(f"  text[:150]: {str(result.get('text'))[:150]}")
print()
print("  Expected (per Decision #237): found=True, ratio around 0.43, ")
print("  candidate = clinical study (NOT 'Complex-Dynamic Origin of Consciousness')")
