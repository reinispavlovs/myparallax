﻿import json
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
log_path = REPO_ROOT / "digests" / "review_log.jsonl"

with open(log_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

print(f"Total log lines: {len(lines)}\n")

suspicious = []
for i, line in enumerate(lines, start=1):
    line_stripped = line.strip()
    if not line_stripped:
        continue
    try:
        entry = json.loads(line_stripped)
    except json.JSONDecodeError:
        suspicious.append((i, "NOT VALID JSON", line_stripped[:100]))
        continue
    # flag entries that look like they contain code/garbage in decision field
    decision = str(entry.get("decision", ""))
    if decision not in ("approved", "rejected"):
        suspicious.append((i, f"unexpected decision={decision!r}", json.dumps(entry)[:150]))

if suspicious:
    print(f"FOUND {len(suspicious)} SUSPICIOUS ENTRIES:\n")
    for ln, reason, content in suspicious:
        print(f"  line {ln}: {reason}")
        print(f"    -> {content}\n")
else:
    print("Log is clean. All entries are valid JSON with decision in {approved, rejected}.")
