﻿import pathlib

p = pathlib.Path("scripts/review_cli.py").resolve()
text = p.read_text(encoding="utf-8")

old = 'DRAFTS_DIR = REPO_ROOT / "myparallax_repo" / "drafts"'
new = 'DRAFTS_DIR = REPO_ROOT / "drafts"'

if old not in text:
    print("[SKIP] Old pattern not found — patch may already be applied or pattern mismatch.")
else:
    text = text.replace(old, new)
    p.write_text(text, encoding="utf-8", newline="")
    print("[OK] Patched DRAFTS_DIR in scripts/review_cli.py")
    print(f"     -> {new}")
