﻿import requests
import time

print("=" * 70)
print("Repeat 'quantum' 5x to check determinism")
print("=" * 70)
url_q = "https://export.arxiv.org/api/query?search_query=all:quantum&start=0&max_results=1"
for i in range(5):
    r = requests.get(url_q, timeout=8)
    print(f"  Attempt {i+1}: {r.status_code}")
    time.sleep(1)

print()
print("=" * 70)
print("Test other common single words")
print("=" * 70)
words = ["gravity", "photon", "neural", "biology", "consciousness", "brain", "acoustic", "granite", "impact", "cosmic"]
for w in words:
    url_w = f"https://export.arxiv.org/api/query?search_query=all:{w}&start=0&max_results=1"
    r = requests.get(url_w, timeout=8)
    print(f"  [{r.status_code}] {w}")
    time.sleep(0.5)
