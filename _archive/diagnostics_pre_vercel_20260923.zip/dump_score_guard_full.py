﻿from pathlib import Path

path = Path("scripts/promote_drafts.py")
text = path.read_text(encoding="utf-8")
lines = text.splitlines()

start = 160
end = 220
for j in range(start, min(end, len(lines))):
    print(f"{j+1}: {lines[j]}")
