﻿from pathlib import Path

path = Path("scripts/promote_drafts.py")
text = path.read_text(encoding="utf-8")
lines = text.splitlines()

for i, line in enumerate(lines, start=1):
    if "promote_one(" in line or "def main(" in line:
        start = max(0, i-2)
        end = min(len(lines), i+15)
        print(f"--- context around line {i} ---")
        for j in range(start, end):
            print(f"{j+1}: {lines[j]}")
        print()
