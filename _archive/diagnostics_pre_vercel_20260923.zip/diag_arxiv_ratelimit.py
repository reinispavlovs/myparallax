﻿import requests
import time

print("=" * 70)
print("RETEST: electron (previously 200, now?)")
print("=" * 70)
url = "https://export.arxiv.org/api/query?search_query=all:electron&start=0&max_results=1"
r = requests.get(url, timeout=8)
print(f"Status: {r.status_code}")

print()
print("=" * 70)
print("Waiting 15 seconds, then retest electron")
print("=" * 70)
time.sleep(15)
r2 = requests.get(url, timeout=8)
print(f"Status: {r2.status_code}")

print()
print("=" * 70)
print("Waiting 15 more seconds, then retest quantum")
print("=" * 70)
time.sleep(15)
url_q = "https://export.arxiv.org/api/query?search_query=all:quantum&start=0&max_results=1"
r3 = requests.get(url_q, timeout=8)
print(f"Status: {r3.status_code}")

print()
print("=" * 70)
print("Full response headers on current 406 (if any)")
print("=" * 70)
r4 = requests.get(url_q, timeout=8)
print(f"Status: {r4.status_code}")
print(f"Headers: {dict(r4.headers)}")
print(f"Body: {r4.text[:1000]}")
