﻿import requests
from urllib.parse import quote

test_queries = [
    "quantum",
    "quantum brain",
    "quantum brain biology",
    "quantum brain biology consciousness",
    "quantum brain biology consciousness out-of-body",
    "quantum brain biology consciousness out-of-body experience",
    "quantum brain biology consciousness out-of-body experience clinical",
    "quantum brain biology consciousness clinical",  # skip hyphen term
    "out-of-body",
    "out-of-body experience",
    "clinical",
    "consciousness clinical",
]

for q in test_queries:
    encoded_query = quote(q)
    url = f"https://export.arxiv.org/api/query?search_query=all:{encoded_query}&start=0&max_results=1"
    try:
        r = requests.get(url, timeout=8)
        status = r.status_code
    except Exception as e:
        status = f"EXC: {e}"
    print(f"[{status}] len={len(q):3d}  query={q!r}")
