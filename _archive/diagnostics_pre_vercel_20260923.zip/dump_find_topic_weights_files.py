﻿from pathlib import Path
import subprocess

root = Path(".")
print("=== Searching for all topic_weights.json files ===")
for p in root.rglob("topic_weights.json"):
    print(f"\n--- {p} ---")
    print("Size:", p.stat().st_size, "bytes")
    print("Modified:", p.stat().st_mtime)
